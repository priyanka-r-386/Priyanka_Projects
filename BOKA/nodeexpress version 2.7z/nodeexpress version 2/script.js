const india = document.getElementById("india");
const norway = document.querySelector("#Norway");
const denmark = document.querySelector("#denmark");
const portugal = document.querySelector("#portugal");
const poland = document.getElementById("poland");
const netherland = document.querySelector("#netherland");
const UK = document.querySelector("#UK");
const serbia = document.querySelector("#serbia");
const finland = document.querySelector("#finland");
const ireland = document.querySelector("#ireland");
const japan = document.querySelector("#japan");
const switzerland = document.querySelector("#switzerland");
const sweden = document.querySelector("#sweden");
const belgium = document.querySelector("#belgium");
const korea = document.querySelector("#korea");
const australia = document.querySelector("#australia");
const canada = document.querySelector("#canada");
const slovenia = document.querySelector("#slovenia");
const spain = document.querySelector("#spain");
const croatia = document.querySelector("#croatia");
const us = document.querySelector("#USA");

const services_group = document.querySelector(".service_group");

async function getBookingData(url, coWorkerClass) {
  const response = await fetch(url);
  const bookingData = response.json();

  bookingData.then((res) => {
    let flag = false;
    res.length > 1 ? (flag = true) : (flag = false);
    flag ? (coworkerbooking = "circle") : (coworkerbooking = "circle-red");
    const element = document.querySelector(coWorkerClass);
    element.classList.add(coworkerbooking);
  });
}

function removeClasslist(classList) {
  document.querySelector(classList).classList.contains("circle")
    ? document.querySelector(classList).classList.remove("circle")
    : document.querySelector(classList).classList.remove("circle-red");
}

async function getActualService(country) {
  const data = await fetch(`http://localhost:8080/${country}`);
  const actualService = data.json();

  return actualService;
}

/*
//Add Indian Market
india.addEventListener("input", function (e) {
  if (india.checked === true) {
    getBookingData("./JsonData/IN/IN_DECORATION.json", ".coworker-booking1-in");
    getBookingData(
      "./JsonData/IN/IN_HOME_FURNISHING_BASIC.json",
      ".coworker-booking2-in"
    );
    getBookingData(
      "./JsonData/IN/IN_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking3-in"
    );
    getBookingData(
      "./JsonData/IN/IN_ID_BUSINESS_REMOTE.json",
      ".coworker-booking4-in"
    );
    getBookingData(
      "./JsonData/IN/IN_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking5-in"
    );
    getBookingData(
      "./JsonData/IN/IN_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking6-in"
    );
    if (services_group.hasChildNodes(".services_india")) {
      services_group.appendChild(document.querySelector(".services_india"));
      document.querySelector(".services_india").style.display = "initial";
    }
  }
  //Remove market when unchecked
  if (india.checked === false) {
    removeClasslist(".coworker-booking1-in");
    removeClasslist(".coworker-booking2-in");
    removeClasslist(".coworker-booking3-in");
    removeClasslist(".coworker-booking4-in");
    removeClasslist(".coworker-booking5-in");
    removeClasslist(".coworker-booking6-in");
    document.querySelector(".services_india").style.display = "none";
  }
});

//Add services to Norway Market
norway.addEventListener("input", function (e) {
  if (norway.checked === true) {
    getBookingData(
      "./JsonData/NO/NO_HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-no"
    );
    getBookingData(
      "./JsonData/NO/NO_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking3-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking4-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_WARDROBE.json",
      ".coworker-booking5-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking6-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking7-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_BATHROOM_STORE.json",
      ".coworker-booking8-no"
    );
    getBookingData(
      "./JsonData/NO/NO_BUSINESS_PLANNING.json",
      ".coworker-booking9-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking10-no"
    );
    services_group.appendChild(document.querySelector(".services_norway"));
    document.querySelector(".services_norway").style.display = "initial";
  }
  //Remove market when unchecked
  if (norway.checked === false) {
    removeClasslist(".coworker-booking1-no");
    removeClasslist(".coworker-booking2-no");
    removeClasslist(".coworker-booking3-no");
    removeClasslist(".coworker-booking4-no");
    removeClasslist(".coworker-booking5-no");
    removeClasslist(".coworker-booking6-no");
    removeClasslist(".coworker-booking7-no");
    removeClasslist(".coworker-booking8-no");
    removeClasslist(".coworker-booking9-no");
    removeClasslist(".coworker-booking10-no");

    document.querySelector(".services_norway").style.display = "none";
  }
});

// Adding Denmark Market
denmark.addEventListener("input", function (e) {
  if (denmark.checked === true) {
    getBookingData(
      "./JsonData/DK/DK_HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-dk"
    );
    getBookingData(
      "./JsonData/DK/DK_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-dk"
    );
    getBookingData(
      "./JsonData/DK/DK_BUSINESS_PLANNING.json",
      ".coworker-booking3-dk"
    );
    getBookingData(
      "./JsonData/DK/DK_PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking4-dk"
    );

    services_group.appendChild(document.querySelector(".services_denmark"));
    document.querySelector(".services_denmark").style.display = "initial";
  }

  //Remove market when unchecked
  if (denmark.checked === false) {
    removeClasslist(".coworker-booking1-dk");
    removeClasslist(".coworker-booking2-dk");
    removeClasslist(".coworker-booking3-dk");
    removeClasslist(".coworker-booking4-dk");
    document.querySelector(".services_denmark").style.display = "none";
  }
});

//Add portugal Market
portugal.addEventListener("input", function (e) {
  if (portugal.checked === true) {
    getBookingData(
      "./JsonData/PT/PT_HOME_FURNISHING_BASIC_CUSTOMER.json",
      ".coworker-booking1-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking3-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_SEASONAL_CUSTOMER.json",
      ".coworker-booking4-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_LIVING_ROOM.json",
      ".coworker-booking5-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking6-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_WARDROBE.json",
      ".coworker-booking7-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_WARDROBE_CUSTOMER.json",
      ".coworker-booking8-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking9-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_BUSINESS_PLANNING.json",
      ".coworker-booking10-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking11-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking12-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking13-pt"
    );

    services_group.appendChild(document.querySelector(".portugal_services "));
    document.querySelector(".portugal_services ").style.display = "initial";
  }
  //Remove market when unchecked
  if (portugal.checked === false) {
    removeClasslist(".coworker-booking1-pt");
    removeClasslist(".coworker-booking2-pt");
    removeClasslist(".coworker-booking3-pt");
    removeClasslist(".coworker-booking4-pt");
    removeClasslist(".coworker-booking5-pt");
    removeClasslist(".coworker-booking6-pt");
    removeClasslist(".coworker-booking7-pt");
    removeClasslist(".coworker-booking8-pt");
    removeClasslist(".coworker-booking9-pt");
    removeClasslist(".coworker-booking10-pt");
    removeClasslist(".coworker-booking11-pt");
    removeClasslist(".coworker-booking12-pt");
    removeClasslist(".coworker-booking13-pt");
    document.querySelector(".portugal_services ").style.display = "none";
  }
});
*/
//Netherland Market

netherland.addEventListener("input", async function (e) {
  if (netherland.checked === true) {
    const data = await getActualService("NL");
    console.log(data);
    const actualService = data[0].map((service) => service);
    document.querySelector(".actual_service_nl").innerHTML = actualService;
    document.querySelector(".customer_book_nl1").classList.add(data[1][0]);
    document.querySelector(".customer_book_nl2").classList.add(data[1][1]);
    getBookingData(
      "./JsonData/NL/NL_PLANNING_LIVING_ROOM.json",
      ".coworker-booking1-nl"
    );
    getBookingData(
      "./JsonData/NL/NL_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking2-nl"
    );
    services_group.appendChild(document.querySelector(".services_netherland"));
    document.querySelector(".services_netherland").style.display = "initial";
  }
  //Remove market when unchecked
  if (netherland.checked === false) {
    removeClasslist(".customer_book_nl1");
    removeClasslist(".customer_book_nl2");
    removeClasslist(".coworker-booking1-nl");
    removeClasslist(".coworker-booking2-nl");
    document.querySelector(".services_netherland").style.display = "none";
  }
});
/*
// Poland Market
poland.addEventListener("input", function (e) {
  if (poland.checked === true) {
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_BASIC_CUSTOMER.json",
      ".coworker-booking2-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking3-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking4-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_COMPLETE_CUSTOMER.json",
      ".coworker-booking5-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking6-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_LIVING_ROOM.json",
      ".coworker-booking7-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking8-pl"
    );

    getBookingData(
      "./JsonData/PL/PL_PLANNING_WARDROBE.json",
      ".coworker-booking9-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking10-pl"
    );

    getBookingData(
      "./JsonData/PL/PL_DECORATION_BUSINESS.json",
      ".coworker-booking11-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_BUSINESS_PLANNING.json",
      ".coworker-booking12-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking13-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_HOME_SMART_REMOTE.json",
      ".coworker-booking14-pl"
    );

    services_group.appendChild(document.querySelector(".services_poland"));
    document.querySelector(".services_poland").style.display = "initial";
  }
  //Remove market when unchecked
  if (poland.checked === false) {
    removeClasslist(".coworker-booking1-pl");
    removeClasslist(".coworker-booking2-pl");
    removeClasslist(".coworker-booking3-pl");
    removeClasslist(".coworker-booking4-pl");
    removeClasslist(".coworker-booking5-pl");
    removeClasslist(".coworker-booking6-pl");
    removeClasslist(".coworker-booking7-pl");
    removeClasslist(".coworker-booking8-pl");
    removeClasslist(".coworker-booking9-pl");
    removeClasslist(".coworker-booking10-pl");
    removeClasslist(".coworker-booking11-pl");
    removeClasslist(".coworker-booking12-pl");
    removeClasslist(".coworker-booking13-pl");
    removeClasslist(".coworker-booking14-pl");
    document.querySelector(".services_poland").style.display = "none";
  }
});

//UK Market
UK.addEventListener("input", function (e) {
  if (UK.checked === true) {
    getBookingData(
      "./JsonData/UK/UK_HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking1-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_LIVING_ROOM.json",
      ".coworker-booking2-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking3-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_WARDROBE.json",
      ".coworker-booking4-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking5-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking6-uk"
    );

    getBookingData(
      "./JsonData/UK/UK_VERIFY_PLANNING_AND_DRAWING.json",
      ".coworker-booking7-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_KITCHEN_STORE.json",
      ".coworker-booking8-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking9-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_INTERIOR_DESIGN_BUSINESS_CONSULTATION.json",
      ".coworker-booking10-uk"
    );
    services_group.appendChild(document.querySelector(".services_uk"));
    document.querySelector(".services_uk").style.display = "initial";
  }

  //Remove market when unchecked
  if (UK.checked === false) {
    removeClasslist(".coworker-booking1-uk");
    removeClasslist(".coworker-booking2-uk");
    removeClasslist(".coworker-booking3-uk");
    removeClasslist(".coworker-booking4-uk");
    removeClasslist(".coworker-booking5-uk");
    removeClasslist(".coworker-booking6-uk");
    removeClasslist(".coworker-booking7-uk");
    removeClasslist(".coworker-booking8-uk");
    removeClasslist(".coworker-booking9-uk");
    removeClasslist(".coworker-booking10-uk");
    document.querySelector(".services_uk").style.display = "none";
  }
});

// Serbia Market
serbia.addEventListener("input", function (e) {
  if (serbia.checked === true) {
    getBookingData(
      "./JsonData/RS/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking1-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_CUSTOMER.json",
      ".coworker-booking2-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking3-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking4-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking5-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking6-rs"
    );
    getBookingData(
      "./JsonData/RS/INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking7-rs"
    );

    services_group.appendChild(document.querySelector(".services_serbia"));
    document.querySelector(".services_serbia").style.display = "initial";
  }
  //Remove market when unchecked
  if (serbia.checked === false) {
    removeClasslist(".coworker-booking1-rs");
    removeClasslist(".coworker-booking2-rs");
    removeClasslist(".coworker-booking3-rs");
    removeClasslist(".coworker-booking4-rs");
    removeClasslist(".coworker-booking5-rs");
    removeClasslist(".coworker-booking6-rs");
    removeClasslist(".coworker-booking7-rs");
    document.querySelector(".services_serbia").style.display = "none";
  }
});

finland.addEventListener("input", function (e) {
  if (finland.checked === true) {
    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-fi"
    );
    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-fi"
    );
    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking3-fi"
    );
    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking4-fi"
    );

    getBookingData(
      "./JsonData/FI/PLANNING_KITCHEN_CUSTOMER.json",
      ".coworker-booking5-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking6-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking7-fi"
    );

    getBookingData(
      "./JsonData/FI/PLANNING_WARDROBE.json",
      ".coworker-booking8-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking9-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking10-fi"
    );
    getBookingData(
      "./JsonData/FI/RENT_A_TRAILER.json",
      ".coworker-booking11-fi"
    );

    services_group.appendChild(document.querySelector(".services_finland"));
    document.querySelector(".services_finland").style.display = "initial";
  }
  //Remove market when unchecked
  if (finland.checked === false) {
    removeClasslist(".coworker-booking1-fi");
    removeClasslist(".coworker-booking2-fi");
    removeClasslist(".coworker-booking3-fi");
    removeClasslist(".coworker-booking4-fi");
    removeClasslist(".coworker-booking5-fi");
    removeClasslist(".coworker-booking6-fi");
    removeClasslist(".coworker-booking7-fi");
    removeClasslist(".coworker-booking8-fi");
    removeClasslist(".coworker-booking9-fi");
    removeClasslist(".coworker-booking10-fi");
    removeClasslist(".coworker-booking11-fi");
    document.querySelector(".services_finland").style.display = "none";
  }
});

ireland.addEventListener("input", function (e) {
  if (ireland.checked === true) {
    getBookingData(
      "./JsonData/IE/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking1-ie"
    );
    getBookingData(
      "./JsonData/IE/PLANNING_WARDROBE.json",
      ".coworker-booking2-ie"
    );
    getBookingData(
      "./JsonData/IE/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking3-ie"
    );
    getBookingData(
      "./JsonData/IE/PLANNING_LIVING_ROOM.json",
      ".coworker-booking4-ie"
    );
    getBookingData(
      "./JsonData/IE/PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking5-ie"
    );

    if (services_group.hasChildNodes(".services_ireland")) {
      services_group.appendChild(document.querySelector(".services_ireland"));
      document.querySelector(".services_ireland").style.display = "initial";
    }
  }
  //Remove market when unchecked
  if (ireland.checked === false) {
    removeClasslist(".coworker-booking1-ie");
    removeClasslist(".coworker-booking2-ie");
    removeClasslist(".coworker-booking3-ie");
    removeClasslist(".coworker-booking4-ie");
    removeClasslist(".coworker-booking5-ie");

    document.querySelector(".services_ireland").style.display = "none";
  }
});

japan.addEventListener("input", function (e) {
  if (japan.checked === true) {
    getBookingData(
      "./JsonData/JP/HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking1-jp"
    );
    getBookingData(
      "./JsonData/JP/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking2-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_WARDROBE.json",
      ".coworker-booking3-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking4-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking5-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking6-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_BUSINESS_ADVANCED_REMOTE.json",
      ".coworker-booking8-jp"
    );
    getBookingData(
      "./JsonData/JP/BUSINESS_PLANNING.json",
      ".coworker-booking9-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking10-jp"
    );
    getBookingData(
      "./JsonData/JP/INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking11-jp"
    );
    getBookingData(
      "./JsonData/JP/ID_BUSINESS_REMOTE.json",
      ".coworker-booking12-jp"
    );
    getBookingData(
      "./JsonData/JP/INTERIOR_DESIGN_BUSINESS_CONSULTATION.json",
      ".coworker-booking13-jp"
    );
    getBookingData(
      "./JsonData/JP/INTERIOR_DESIGN_BUSINESS_CONSULTATION_REMOTE.json",
      ".coworker-booking14-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking15-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_SLEEP_REMOTE.json",
      ".coworker-booking16-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking7-jp"
    );

    services_group.appendChild(document.querySelector(".services_japan"));

    document.querySelector(".services_japan").style.display = "initial";
  }
  //Remove market when unchecked
  if (japan.checked === false) {
    removeClasslist(".coworker-booking1-jp");
    removeClasslist(".coworker-booking2-jp");
    removeClasslist(".coworker-booking3-jp");
    removeClasslist(".coworker-booking4-jp");
    removeClasslist(".coworker-booking5-jp");
    removeClasslist(".coworker-booking6-jp");
    removeClasslist(".coworker-booking7-jp");
    removeClasslist(".coworker-booking8-jp");
    removeClasslist(".coworker-booking9-jp");
    removeClasslist(".coworker-booking10-jp");
    removeClasslist(".coworker-booking11-jp");
    removeClasslist(".coworker-booking12-jp");
    removeClasslist(".coworker-booking13-jp");
    removeClasslist(".coworker-booking14-jp");
    removeClasslist(".coworker-booking15-jp");
    removeClasslist(".coworker-booking16-jp");
    document.querySelector(".services_japan").style.display = "none";
  }
});

switzerland.addEventListener("input", function (e) {
  if (switzerland.checked === true) {
    getBookingData(
      "./JsonData/CH/HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-ch"
    );
    getBookingData(
      "./JsonData/CH/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-ch"
    );
    getBookingData(
      "./JsonData/CH/HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking3-ch"
    );
    getBookingData(
      "./JsonData/CH/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking4-ch"
    );
    getBookingData(
      "./JsonData/CH/BUSINESS_PLANNING.json",
      ".coworker-booking5-ch"
    );
    getBookingData(
      "./JsonData/CH/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking6-ch"
    );

    services_group.appendChild(document.querySelector(".services_switzerland"));
    document.querySelector(".services_switzerland").style.display = "initial";
  }

  //Remove market when unchecked
  if (switzerland.checked === false) {
    removeClasslist(".coworker-booking1-ch");
    removeClasslist(".coworker-booking2-ch");
    removeClasslist(".coworker-booking3-ch");
    removeClasslist(".coworker-booking4-ch");
    removeClasslist(".coworker-booking5-ch");
    removeClasslist(".coworker-booking6-ch");

    document.querySelector(".services_switzerland").style.display = "none";
  }
});

sweden.addEventListener("input", function (e) {
  if (sweden.checked === true) {
    getBookingData(
      "./JsonData/SE/HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-se"
    );
    getBookingData(
      "./JsonData/SE/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_WARDROBE.json",
      ".coworker-booking3-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking4-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_WORKSPACES.json",
      ".coworker-booking5-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_WORKSPACES_REMOTE.json",
      ".coworker-booking6-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking7-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_BATHROOM_STORE.json",
      ".coworker-booking8-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SLEEP.json",
      ".coworker-booking9-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SLEEP_REMOTE.json",
      ".coworker-booking10-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SOFA.json",
      ".coworker-booking11-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SOFA_REMOTE.json",
      ".coworker-booking12-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SEASONAL.json",
      ".coworker-booking13-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SEASONAL_REMOTE.json",
      ".coworker-booking14-se"
    );

    getBookingData(
      "./JsonData/SE/PLANNING_LIVING_ROOM.json",
      ".coworker-booking15-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking16-se"
    );

    services_group.appendChild(document.querySelector(".services_sweden"));
    document.querySelector(".services_sweden").style.display = "initial";
  }

  //Remove market when unchecked
  if (sweden.checked === false) {
    removeClasslist(".coworker-booking1-se");
    removeClasslist(".coworker-booking2-se");
    removeClasslist(".coworker-booking3-se");
    removeClasslist(".coworker-booking4-se");
    removeClasslist(".coworker-booking5-se");
    removeClasslist(".coworker-booking6-se");
    removeClasslist(".coworker-booking7-se");
    removeClasslist(".coworker-booking8-se");
    removeClasslist(".coworker-booking9-se");
    removeClasslist(".coworker-booking10-se");
    removeClasslist(".coworker-booking11-se");
    removeClasslist(".coworker-booking12-se");
    removeClasslist(".coworker-booking13-se");
    removeClasslist(".coworker-booking14-se");
    removeClasslist(".coworker-booking15-se");
    removeClasslist(".coworker-booking16-se");

    document.querySelector(".services_sweden").style.display = "none";
  }
});

belgium.addEventListener("input", function (e) {
  if (belgium.checked === true) {
    getBookingData(
      "./JsonData/BE/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking1-be"
    );
    getBookingData(
      "./JsonData/BE/BUSINESS_PLANNING.json",
      ".coworker-booking2-be"
    );
    getBookingData(
      "./JsonData/BE/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking3-be"
    );
    getBookingData(
      "./JsonData/BE/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking4-be"
    );
    getBookingData(
      "./JsonData/BE/PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking5-be"
    );
    getBookingData(
      "./JsonData/BE/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking6-be"
    );
    getBookingData(
      "./JsonData/BE/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking7-be"
    );

    services_group.appendChild(document.querySelector(".services_belgium"));
    document.querySelector(".services_belgium").style.display = "initial";
  }

  //Remove market when unchecked
  if (belgium.checked === false) {
    removeClasslist(".coworker-booking1-be");
    removeClasslist(".coworker-booking2-be");
    removeClasslist(".coworker-booking3-be");
    removeClasslist(".coworker-booking4-be");
    removeClasslist(".coworker-booking5-be");
    removeClasslist(".coworker-booking6-be");
    removeClasslist(".coworker-booking7-be");
    document.querySelector(".services_belgium").style.display = "none";
  }
});

korea.addEventListener("input", function (e) {
  if (korea.checked === true) {
    getBookingData(
      "./JsonData/KR/INTERIOR_DESIGN.json",
      ".coworker-booking1-kr"
    );
    getBookingData(
      "./JsonData/KR/HOME_FURNISHING_BASIC.json",
      ".coworker-booking2-kr"
    );
    getBookingData(
      "./JsonData/KR/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking3-kr"
    );
    getBookingData(
      "./JsonData/KR/PLANNING_LIVING_ROOM.json",
      ".coworker-booking4-kr"
    );
    getBookingData(
      "./JsonData/KR/VERIFY_PLANNING_AND_DRAWING.json",
      ".coworker-booking5-kr"
    );
    getBookingData(
      "./JsonData/KR/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking6-kr"
    );
    getBookingData(
      "./JsonData/KR/KITCHEN_INSTALLATION_QUOTATION.json",
      ".coworker-booking7-kr"
    );
    getBookingData(
      "./JsonData/KR/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking8-kr"
    );
    getBookingData(
      "./JsonData/KR/BUSINESS_PLANNING.json",
      ".coworker-booking9-kr"
    );
    getBookingData(
      "./JsonData/KR/INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking10-kr"
    );
    getBookingData(
      "./JsonData/KR/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking11-kr"
    );

    services_group.appendChild(document.querySelector(".services_korea"));
    document.querySelector(".services_korea").style.display = "initial";
  }

  //Remove market when unchecked
  if (korea.checked === false) {
    removeClasslist(".coworker-booking1-kr");
    removeClasslist(".coworker-booking2-kr");
    removeClasslist(".coworker-booking3-kr");
    removeClasslist(".coworker-booking4-kr");
    removeClasslist(".coworker-booking5-kr");
    removeClasslist(".coworker-booking6-kr");
    removeClasslist(".coworker-booking7-kr");
    removeClasslist(".coworker-booking8-kr");
    removeClasslist(".coworker-booking9-kr");
    removeClasslist(".coworker-booking10-kr");
    removeClasslist(".coworker-booking11-kr");

    document.querySelector(".services_korea").style.display = "none";
  }
});
*/
australia.addEventListener("input", async function (e) {
  if (australia.checked === true) {
    const data = await getActualService("AU");
    const actualService = data[0].map((service) => service);
    document.querySelector(".actual_service").innerHTML = actualService;
    document.querySelector(".customer_book_au1").classList.add(data[1][0]);
    document.querySelector(".customer_book_au2").classList.add(data[1][1]);

    getBookingData(
      "./JsonData/AU/BUSINESS_PLANNING.json",
      ".coworker-booking1-au"
    );
    getBookingData(
      "./JsonData/AU/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking2-au"
    );

    services_group.appendChild(document.querySelector(".services_australia"));
    document.querySelector(".services_australia").style.display = "initial";
  }

  //Remove market when unchecked
  if (australia.checked === false) {
    removeClasslist(".customer_book_au1");
    removeClasslist(".customer_book_au2");
    removeClasslist(".coworker-booking1-au");
    removeClasslist(".coworker-booking2-au");

    document.querySelector(".services_australia").style.display = "none";
  }
});
/*
canada.addEventListener("input", function (e) {
  if (canada.checked === true) {
    getBookingData(
      "./JsonData/CA/HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-ca"
    );
    getBookingData(
      "./JsonData/CA/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-ca"
    );
    getBookingData(
      "./JsonData/CA/HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking3-ca"
    );
    getBookingData(
      "./JsonData/CA/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking4-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking5-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking6-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking7-ca"
    );
    getBookingData(
      "./JsonData/CA/BUSINESS_PLANNING.json",
      ".coworker-booking8-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_BUSINESS_ADVANCED.json",
      ".coworker-booking9-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_BUSINESS_ADVANCED_REMOTE.json",
      ".coworker-booking10-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking11-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking11-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking12-ca"
    );

    getBookingData(
      "./JsonData/CA/PLANNING_WARDROBE.json",
      ".coworker-booking13-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking14-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_SLEEP.json",
      ".coworker-booking15-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_SLEEP_REMOTE.json",
      ".coworker-booking16-ca"
    );

    services_group.appendChild(document.querySelector(".services_canada"));
    document.querySelector(".services_canada").style.display = "initial";
  }

  //Remove market when unchecked
  if (canada.checked === false) {
    removeClasslist(".coworker-booking1-ca");
    removeClasslist(".coworker-booking2-ca");
    removeClasslist(".coworker-booking3-ca");
    removeClasslist(".coworker-booking4-ca");
    removeClasslist(".coworker-booking5-ca");
    removeClasslist(".coworker-booking6-ca");
    removeClasslist(".coworker-booking7-ca");
    removeClasslist(".coworker-booking8-ca");
    removeClasslist(".coworker-booking9-ca");
    removeClasslist(".coworker-booking10-ca");
    removeClasslist(".coworker-booking11-ca");
    removeClasslist(".coworker-booking12-ca");
    removeClasslist(".coworker-booking13-ca");
    removeClasslist(".coworker-booking14-ca");
    removeClasslist(".coworker-booking15-ca");
    removeClasslist(".coworker-booking16-ca");

    document.querySelector(".services_canada").style.display = "none";
  }
});

slovenia.addEventListener("input", function (e) {
  if (slovenia.checked === true) {
    getBookingData(
      "./JsonData/SI/PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking1-si"
    );
    getBookingData(
      "./JsonData/SI/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking2-si"
    );
    getBookingData(
      "./JsonData/SI/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking3-si"
    );
    getBookingData(
      "./JsonData/SI/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking4-si"
    );

    services_group.appendChild(document.querySelector(".services_slovenia"));
    document.querySelector(".services_slovenia").style.display = "initial";
  }

  //Remove market when unchecked
  if (slovenia.checked === false) {
    removeClasslist(".coworker-booking1-si");
    removeClasslist(".coworker-booking2-si");
    removeClasslist(".coworker-booking3-si");
    removeClasslist(".coworker-booking4-si");

    document.querySelector(".services_slovenia").style.display = "none";
  }
});

spain.addEventListener("input", function (e) {
  if (spain.checked === true) {
    getBookingData(
      "./JsonData/ES/HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-es"
    );
    getBookingData(
      "./JsonData/ES/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-es"
    );
    getBookingData(
      "./JsonData/ES/HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking3-es"
    );
    getBookingData(
      "./JsonData/ES/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking4-es"
    );
    getBookingData(
      "./JsonData/ES/INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking5-es"
    );
    getBookingData(
      "./JsonData/ES/ID_BUSINESS_REMOTE.json",
      ".coworker-booking6-es"
    );
    getBookingData(
      "./JsonData/ES/PLANNING_BUSINESS_ADVANCED.json",
      ".coworker-booking7-es"
    );
    getBookingData(
      "./JsonData/ES/PLANNING_BUSINESS_ADVANCED_REMOTE.json",
      ".coworker-booking8-es"
    );
    getBookingData(
      "./JsonData/ES/ID_BUSINESS_REMOTE_MEDIUM.json",
      ".coworker-booking9-es"
    );
    getBookingData(
      "./JsonData/ES/ID_BUSINESS_REMOTE_MEDIUM.json",
      ".coworker-booking10-es"
    );
    getBookingData(
      "./JsonData/ES/INTERIOR_DESIGN_BUSINESS_CONSULTATION_REMOTE.json",
      ".coworker-booking11-es"
    );
    getBookingData(
      "./JsonData/ES/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking12-es"
    );
    getBookingData(
      "./JsonData/ES/PLANNING_BATHROOM_STORE.json",
      ".coworker-booking13-es"
    );
    services_group.appendChild(document.querySelector(".services_spain"));
    document.querySelector(".services_spain").style.display = "initial";
  }

  //Remove market when unchecked
  if (spain.checked === false) {
    removeClasslist(".coworker-booking1-es");
    removeClasslist(".coworker-booking2-es");
    removeClasslist(".coworker-booking3-es");
    removeClasslist(".coworker-booking4-es");
    removeClasslist(".coworker-booking5-es");
    removeClasslist(".coworker-booking6-es");
    removeClasslist(".coworker-booking7-es");
    removeClasslist(".coworker-booking8-es");
    removeClasslist(".coworker-booking9-es");
    removeClasslist(".coworker-booking10-es");
    removeClasslist(".coworker-booking11-es");
    removeClasslist(".coworker-booking12-es");
    removeClasslist(".coworker-booking13-es");

    document.querySelector(".services_spain").style.display = "none";
  }
});

croatia.addEventListener("input", function (e) {
  if (croatia.checked === true) {
    getBookingData(
      "./JsonData/HR/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking1-hr"
    );
    getBookingData(
      "./JsonData/HR/PLANNING_BATHROOM_STORE.json",
      ".coworker-booking2-hr"
    );
    getBookingData("./JsonData/HR/HOME_PLANNING.json", ".coworker-booking3-hr");
    getBookingData(
      "./JsonData/HR/PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking4-hr"
    );
    getBookingData(
      "./JsonData/HR/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking5-hr"
    );
    getBookingData(
      "./JsonData/HR/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking6-hr"
    );
    getBookingData(
      "./JsonData/HR/BUSINESS_PLANNING.json",
      ".coworker-booking7-hr"
    );
    getBookingData(
      "./JsonData/HR/PLANNING_WARDROBE.json",
      ".coworker-booking8-hr"
    );
    getBookingData(
      "./JsonData/HR/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking9-hr"
    );

    services_group.appendChild(document.querySelector(".services_croatia"));
    document.querySelector(".services_croatia").style.display = "initial";
  }

  //Remove market when unchecked
  if (croatia.checked === false) {
    removeClasslist(".coworker-booking1-hr");
    removeClasslist(".coworker-booking2-hr");
    removeClasslist(".coworker-booking3-hr");
    removeClasslist(".coworker-booking4-hr");
    removeClasslist(".coworker-booking5-hr");
    removeClasslist(".coworker-booking6-hr");
    removeClasslist(".coworker-booking7-hr");
    removeClasslist(".coworker-booking8-hr");
    removeClasslist(".coworker-booking9-hr");

    document.querySelector(".services_croatia").style.display = "none";
  }
});

us.addEventListener("input", function (e) {
  if (us.checked === true) {
    getBookingData(
      "./JsonData/US/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking1-us"
    );
    getBookingData(
      "./JsonData/US/PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking2-us"
    );
    getBookingData(
      "./JsonData/US/VERIFY_PLANNING_AND_DRAWING.json",
      ".coworker-booking3-us"
    );
    getBookingData(
      "./JsonData/US/PLANNING_KITCHEN_STORE.json",
      ".coworker-booking4-us"
    );
    getBookingData(
      "./JsonData/US/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking5-us"
    );
    getBookingData(
      "./JsonData/US/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking6-us"
    );

    services_group.appendChild(document.querySelector(".services_usa"));
    document.querySelector(".services_usa").style.display = "initial";
  }

  //Remove market when unchecked
  if (us.checked === false) {
    removeClasslist(".coworker-booking1-us");
    removeClasslist(".coworker-booking2-us");
    removeClasslist(".coworker-booking3-us");
    removeClasslist(".coworker-booking4-us");
    removeClasslist(".coworker-booking5-us");
    removeClasslist(".coworker-booking6-us");

    document.querySelector(".services_usa").style.display = "none";
  }
});

*/
