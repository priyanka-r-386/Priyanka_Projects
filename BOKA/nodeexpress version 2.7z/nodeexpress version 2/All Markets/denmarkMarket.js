const express = require("express");
const data_services = require("../nodejs");
const app = express();
const pinCode = "1620";
const language = "da-dk";
const services = ["DESIGN", "BUSINESS", "BATHROOM"];
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesignDenmark(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_dk = designServices;
    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookDKDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_dk = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessDenmark(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_dk = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookDKBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_dk = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBathroomDenmark(req, res, next) {
  try {
    const bathroom = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const bathroomService = bathroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bathroom_dk = bathroomService;
    const locationService = bathroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookDKBathroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bathroom_dk = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = { getDesignDenmark, getBusinessDenmark, getBathroomDenmark };
