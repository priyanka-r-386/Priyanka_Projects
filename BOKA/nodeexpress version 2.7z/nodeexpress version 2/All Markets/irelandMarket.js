const express = require("express");
const data_services = require("../nodejs");
const app = express();
const pinCode = "D11 FW18";
const language = "en-ie";
const services = ["DESIGN", "BEDROOM", "LIVINGROOM"];
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesignIreland(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_ie = designServices;
    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookIEDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_ie = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBedroomIreland(req, res, next) {
  try {
    const bedroom = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const bedroomService = bedroom.data.map((sd) => sd.serviceProductId + "\n");
    bedroom_ie = bedroomService;
    const locationService = bedroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookIEBedroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bedroom_ie = [error.response.status, error.response.statusText];
    next();
  }
}

async function getLrIreland(req, res, next) {
  try {
    const Lr = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const LrService = Lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_ie = LrService;
    const locationService = Lr.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookIELr = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    lr_ie = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = { getDesignIreland, getBedroomIreland, getLrIreland };
