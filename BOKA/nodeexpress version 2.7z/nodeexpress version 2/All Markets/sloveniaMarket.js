const express = require("express");
const data_services = require("../nodejs");
const app = express();
const pinCode = "1000";
const language = "sl-si";
const services = ["KITCHEN", "BEDROOM"];
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getKitchen(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_si = kitchenService;

    const locationService = kitchen.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookSIKitchen = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    kitchen_si = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBedroom(req, res, next) {
  try {
    const bedroom = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const bedroomServices = bedroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bedroom_si = bedroomServices;

    const locationService = bedroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookSIBedroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bedroom_si = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getKitchen,
  getBedroom,
};
