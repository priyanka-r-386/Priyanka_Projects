const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = [
  "DESIGN",
  "PAX",
  "BEDROOM",
  "BATHROOM",
  "LIVINGROOM",
  "SOFA",
  "SEASONAL",
  "WORKSPACE",
];
const pinCode = "25268";
const language = "sv-se";
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesignSweden(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_se = designServices;

    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookSEDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_se = [error.response.status, error.response.statusText];
    next();
  }
}

async function getPaxSweden(req, res, next) {
  try {
    const pax = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const paxServices = pax.data.map((sd) => sd.serviceProductId + "\n");
    pax_se = paxServices;

    const locationService = pax.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookSEPax = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    pax_jp = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBedroomSweden(req, res, next) {
  try {
    const bedroom = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const bedroomServices = bedroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bedroom_se = bedroomServices;

    const locationService = bedroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookSEBedroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bedroom_se = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBathroomSweden(req, res, next) {
  try {
    const bathroom = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const bathroomService = bathroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bathroom_se = bathroomService;
    const locationService = bathroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookSEBathroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bathroom_jp = [error.response.status, error.response.statusText];
    next();
  }
}

async function getLivingRoomSweden(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[4],
      pinCode,
      language
    );

    const lrService = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_se = lrService;
    const locationService = lr.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookSELr = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    lr_se = [error.response.status, error.response.statusText];
    next();
  }
}

async function getSofaSweden(req, res, next) {
  try {
    const sofa = await data_services.getServiceData(
      services[5],
      pinCode,
      language
    );

    const sofaService = sofa.data.map((sd) => sd.serviceProductId + "\n");
    sofa_se = sofaService;
    const locationService = sofa.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookSESofa = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    sofa_se = [error.response.status, error.response.statusText];
    next();
  }
}

async function getSeasonalSweden(req, res, next) {
  try {
    const seasonal = await data_services.getServiceData(
      services[6],
      pinCode,
      language
    );

    const seasonalService = seasonal.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    seasonal_se = seasonalService;
    const locationService = seasonal.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookSESeasonal = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    seasonal_se = [error.response.status, error.response.statusText];
    next();
  }
}

async function getWorkspaceSweden(req, res, next) {
  try {
    const Workspace = await data_services.getServiceData(
      services[7],
      pinCode,
      language
    );

    const WorkspaceService = Workspace.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    Workspace_se = WorkspaceService;
    const locationService = Workspace.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookSEWorkspace = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    Workspace_se = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getPaxSweden,
  getSofaSweden,
  getBathroomSweden,
  getBedroomSweden,
  getLivingRoomSweden,
  getSeasonalSweden,
  getWorkspaceSweden,
  getDesignSweden,
};
