const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = [
  "DESIGN",
  "BATHROOM",
  "BUSINESS",
  "BUSINESSINTERIORDESIGN",
  "BUSINESSDESIGNCONSULTATION",
];
const pinCode = "28701";
const language = "es-es";
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesign(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_es = designServices;

    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookESDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_es = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusiness(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_es = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookESBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_es = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessInteriorDesign(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    businessID_es = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookESBusinessID = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    businessID_es = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessDesignConsultation(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[4],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    businessDC_es = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookESBusinessDC = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    businessDC_es = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBathroom(req, res, next) {
  try {
    const bathroom = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const bathroomService = bathroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bathroom_es = bathroomService;
    const locationService = bathroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookESBathroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bathroom_es = [error.response.status, error.response.statusText];
    next();
  }
}
module.exports = {
  getBathroom,
  getBusinessDesignConsultation,
  getBusinessInteriorDesign,
  getBusiness,
  getDesign,
};
