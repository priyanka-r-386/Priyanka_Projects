const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = ["PAX", "LIVINGROOM", "BUSINESS", "KITCHEN", "BATHROOM"];
const pinCode = "1930";
const language = "nl-be";
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getPaxBelgium(req, res, next) {
  try {
    const pax = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const paxServices = pax.data.map((sd) => sd.serviceProductId + "\n");
    pax_be = paxServices;

    const locationService = pax.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookBEPax = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    pax_be = [error.response.status, error.response.statusText];
    next();
  }
}

async function getLRBelgium(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_be = lrServices;

    const locationService = lr.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookBELr = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    lr_be = [error.response.status, error.response.statusText];
    next();
  }
}

async function getKitchenBelgium(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_be = kitchenService;

    const locationService = kitchen.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookBEKitchen = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    kitchen_be = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessBelgium(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_be = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookBEBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_be = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBathroomBelgium(req, res, next) {
  try {
    const bathroom = await data_services.getServiceData(
      services[4],
      pinCode,
      language
    );

    const bathroomService = bathroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bathroom_be = bathroomService;
    const locationService = bathroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookBEBathroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bathroom_be = [error.response.status, error.response.statusText];
    next();
  }
}
module.exports = {
  getPaxBelgium,
  getBathroomBelgium,
  getBusinessBelgium,
  getKitchenBelgium,
  getLRBelgium,
};
