const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = ["DESIGN", "BEDROOM", "BUSINESS", "KITCHEN"];
const pinCode = "11231";
const language = "sr-rs";
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesignSerbia(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_sr = designServices;
    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);
    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookRSDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_sr = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBedroomSerbia(req, res, next) {
  try {
    const bedroom = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const bedroomServices = bedroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bedroom_sr = bedroomServices;
    const locationService = bedroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);
    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookRSBedroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bedroom_sr = [error.response.status, error.response.statusText];
    next();
  }
}

async function getKitchenSerbia(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_sr = kitchenService;
    const locationService = kitchen.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);
    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookRSKitchen = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    kitchen_sr = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessSerbia(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_sr = businessService;
    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);
    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookRSBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_sr = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getBedroomSerbia,
  getBusinessSerbia,
  getDesignSerbia,
  getKitchenSerbia,
};
