const express = require("express");
const data_services = require("../nodejs");
const app = express();
const pinCode = "K2C3S4";
const language = "en-ca";
const services = [
  "DESIGN",
  "LIVINGROOM",
  "KITCHEN",
  "BUSINESS",
  "BEDROOM",
  "BATHROOM",
];
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesign(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_ca = designServices;
    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookCADesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_ca = [error.response.status, error.response.statusText];
    next();
  }
}

async function getKitchen(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_ca = kitchenService;

    const locationService = kitchen.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookCAKitchen = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    kitchen_ca = [error.response.status, error.response.statusText];
    next();
  }
}

async function getLR(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_ca = lrServices;

    const locationService = lr.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookCALr = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    lr_ca = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusiness(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_ca = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookCABusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_ca = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBedroom(req, res, next) {
  try {
    const bedroom = await data_services.getServiceData(
      services[4],
      pinCode,
      language
    );

    const bedroomServices = bedroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bedroom_ca = bedroomServices;

    const locationService = bedroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookCABedroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bedroom_ca = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBathroom(req, res, next) {
  try {
    const bathroom = await data_services.getServiceData(
      services[5],
      pinCode,
      language
    );

    const bathroomService = bathroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bathroom_ca = bathroomService;
    const locationService = bathroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookCABathroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bathroom_ca = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getDesign,
  getLR,
  getKitchen,
  getBusiness,
  getBathroom,
  getBedroom,
};
