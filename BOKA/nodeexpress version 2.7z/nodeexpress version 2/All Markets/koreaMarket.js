const express = require("express");
const data_services = require("../nodejs");
const app = express();
const pinCode = "14284";
const language = "en-kr";
const services = ["DESIGN", "LIVINGROOM", "KITCHEN", "BUSINESS"];
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesignKorea(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_kr = designServices;
    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookKRDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_kr = [error.response.status, error.response.statusText];
    next();
  }
}

async function getKitchenKorea(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_kr = kitchenService;

    const locationService = kitchen.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookKRKitchen = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    kitchen_kr = [error.response.status, error.response.statusText];
    next();
  }
}

async function getLRKorea(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_kr = lrServices;

    const locationService = lr.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookKRLr = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    lr_kr = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessKorea(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_kr = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookKRBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_kr = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getDesignKorea,
  getLRKorea,
  getKitchenKorea,
  getBusinessKorea,
};
