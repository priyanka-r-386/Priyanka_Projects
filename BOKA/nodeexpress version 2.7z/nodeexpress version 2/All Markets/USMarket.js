const express = require("express");
const data_services = require("../nodejs");
const app = express();
const pinCode = "90202";
const language = "en-us";
const services = ["BEDROOM", "LIVINGROOM", "KITCHEN", "BUSINESS"];
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getBedroom(req, res, next) {
  try {
    const bedroom = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const bedroomServices = bedroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bedroom_us = bedroomServices;

    const locationService = bedroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookUSBedroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bedroom_us = [error.response.status, error.response.statusText];
    next();
  }
}

async function getKitchen(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_us = kitchenService;

    const locationService = kitchen.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookUSKitchen = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    kitchen_us = [error.response.status, error.response.statusText];
    next();
  }
}

async function getLR(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_us = lrServices;

    const locationService = lr.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookUSLr = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    lr_us = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusiness(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_us = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookUSBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_us = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getBedroom,
  getLR,
  getKitchen,
  getBusiness,
};
