const india = document.getElementById("india");
const norway = document.querySelector("#Norway");
const denmark = document.querySelector("#denmark");
const portugal = document.querySelector("#portugal");
const poland = document.getElementById("poland");
const netherland = document.querySelector("#netherland");
const UK = document.querySelector("#UK");
const serbia = document.querySelector("#serbia");
const finland = document.querySelector("#finland");
const ireland = document.querySelector("#ireland");
const japan = document.querySelector("#japan");
const switzerland = document.querySelector("#switzerland");
const sweden = document.querySelector("#sweden");
const belgium = document.querySelector("#belgium");
const korea = document.querySelector("#korea");
const australia = document.querySelector("#australia");
const canada = document.querySelector("#canada");
const slovenia = document.querySelector("#slovenia");
const spain = document.querySelector("#spain");
const croatia = document.querySelector("#croatia");
const us = document.querySelector("#USA");

const services_group = document.querySelector(".service_group");

async function getBookingData(url, coWorkerClass) {
  const response = await fetch(url);
  const bookingData = response.json();

  bookingData.then((res) => {
    let flag = false;
    res.length > 1 ? (flag = true) : (flag = false);
    flag ? (coworkerbooking = "circle") : (coworkerbooking = "circle-red");
    const element = document.querySelector(coWorkerClass);
    element.classList.add(coworkerbooking);
  });
}

function removeClasslist(classLists) {
  for (const classList in classLists) {
    document.querySelector(classLists[classList]).classList.contains("circle")
      ? document.querySelector(classLists[classList]).classList.remove("circle")
      : document
          .querySelector(classLists[classList])
          .classList.remove("circle-red");
  }
}

async function getActualService(country) {
  const data = await fetch(`http://localhost:8080/${country}`);
  const actualService = data.json();
  return actualService;
}

//Add Indian Market
india.addEventListener("input", async function (e) {
  if (india.checked === true) {
    const data = await getActualService("IN");
    const actualServiceDesign = data[0].map((service) => service);
    const actualServiceLr = data[1].map((service) => service);
    const actualServicePax = data[2].map((service) => service);
    document.querySelector(".design_in").innerHTML = actualServiceDesign;
    document.querySelector(".lr_in").innerHTML = actualServiceLr;
    document.querySelector(".pax_in").innerHTML = actualServicePax;
    document.querySelector(".cust_book_in1").classList.add(data[3][0]);
    document.querySelector(".cust_book_in2").classList.add(data[3][1]);
    document.querySelector(".cust_book_in3").classList.add(data[3][2]);
    document.querySelector(".cust_book_in4").classList.add(data[3][3]);
    document.querySelector(".cust_book_in5").classList.add(data[4]);
    document.querySelector(".cust_book_in6").classList.add(data[5]);

    getBookingData("./JsonData/IN/IN_DECORATION.json", ".coworker-booking1-in");
    getBookingData(
      "./JsonData/IN/IN_HOME_FURNISHING_BASIC.json",
      ".coworker-booking2-in"
    );
    getBookingData(
      "./JsonData/IN/IN_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking3-in"
    );
    getBookingData(
      "./JsonData/IN/IN_ID_BUSINESS_REMOTE.json",
      ".coworker-booking4-in"
    );
    getBookingData(
      "./JsonData/IN/IN_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking5-in"
    );
    getBookingData(
      "./JsonData/IN/IN_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking6-in"
    );
    if (services_group.hasChildNodes(".services_india")) {
      services_group.appendChild(document.querySelector(".services_india"));
      document.querySelector(".services_india").style.display = "initial";
    }
  }
  //Remove market when unchecked
  if (india.checked === false) {
    const removeElement = [
      ".cust_book_in1",
      ".cust_book_in2",
      ".cust_book_in3",
      ".cust_book_in4",
      ".cust_book_in5",
      ".cust_book_in6",
      ".coworker-booking1-in",
      ".coworker-booking2-in",
      ".coworker-booking3-in",
      ".coworker-booking4-in",
      ".coworker-booking5-in",
      ".coworker-booking6-in",
    ];
    removeClasslist(removeElement);
    document.querySelector(".services_india").style.display = "none";
  }
});

//Add services to Norway Market
norway.addEventListener("input", async function (e) {
  if (norway.checked === true) {
    const data = await getActualService("no");

    document.querySelector(".design_no").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".pax_no").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".kitchen_no").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".bathroom_no").innerHTML = data[3].map(
      (service) => service
    );
    document.querySelector(".business_no").innerHTML = data[4].map(
      (service) => service
    );
    document.querySelector(".cust_book_no1").classList.add(data[5][0]);
    document.querySelector(".cust_book_no2").classList.add(data[5][1]);
    document.querySelector(".cust_book_no3").classList.add(data[7][0]);
    document.querySelector(".cust_book_no4").classList.add(data[7][1]);
    document.querySelector(".cust_book_no5").classList.add(data[6][0]);
    document.querySelector(".cust_book_no6").classList.add(data[6][1]);
    document.querySelector(".cust_book_no7").classList.add(data[8][0]);
    document.querySelector(".cust_book_no8").classList.add(data[8][1]);
    document.querySelector(".cust_book_no9").classList.add(data[9][0]);
    document.querySelector(".cust_book_no10").classList.add(data[9][1]);
    getBookingData(
      "./JsonData/NO/NO_HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-no"
    );
    getBookingData(
      "./JsonData/NO/NO_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking3-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking4-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_WARDROBE.json",
      ".coworker-booking5-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking6-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking7-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_BATHROOM_STORE.json",
      ".coworker-booking8-no"
    );
    getBookingData(
      "./JsonData/NO/NO_BUSINESS_PLANNING.json",
      ".coworker-booking9-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking10-no"
    );
    services_group.appendChild(document.querySelector(".services_norway"));
    document.querySelector(".services_norway").style.display = "initial";
  }
  //Remove market when unchecked
  if (norway.checked === false) {
    const removeElement = [
      ".cust_book_no1",
      ".cust_book_no2",
      ".cust_book_no3",
      ".cust_book_no4",
      ".cust_book_no5",
      ".cust_book_no6",
      ".cust_book_no7",
      ".cust_book_no8",
      ".cust_book_no9",
      ".cust_book_no10",
      ".coworker-booking1-no",
      ".coworker-booking2-no",
      ".coworker-booking3-no",
      ".coworker-booking4-no",
      ".coworker-booking5-no",
      ".coworker-booking6-no",
      ".coworker-booking7-no",
      ".coworker-booking8-no",
      ".coworker-booking9-no",
      ".coworker-booking10-no",
    ];

    removeClasslist(removeElement);

    document.querySelector(".services_norway").style.display = "none";
  }
});

// Adding Denmark Market
denmark.addEventListener("input", async function (e) {
  if (denmark.checked === true) {
    const data = await getActualService("DK");
    document.querySelector(".design_dk").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".business_dk").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".bathroom_dk").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".cust_book_dk1").classList.add(data[3][0]);
    document.querySelector(".cust_book_dk2").classList.add(data[3][1]);
    document.querySelector(".cust_book_dk3").classList.add(data[4][0]);
    document.querySelector(".cust_book_dk4").classList.add(data[5][0]);

    getBookingData(
      "./JsonData/DK/DK_HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-dk"
    );
    getBookingData(
      "./JsonData/DK/DK_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-dk"
    );
    getBookingData(
      "./JsonData/DK/DK_BUSINESS_PLANNING.json",
      ".coworker-booking3-dk"
    );
    getBookingData(
      "./JsonData/DK/DK_PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking4-dk"
    );

    services_group.appendChild(document.querySelector(".services_denmark"));
    document.querySelector(".services_denmark").style.display = "initial";
  }

  //Remove market when unchecked
  if (denmark.checked === false) {
    const removeElement = [
      ".cust_book_dk1",
      ".cust_book_dk2",
      ".cust_book_dk3",
      ".cust_book_dk4",
      ".coworker-booking1-dk",
      ".coworker-booking2-dk",
      ".coworker-booking3-dk",
      ".coworker-booking4-dk",
    ];
    removeClasslist(removeElement);

    document.querySelector(".services_denmark").style.display = "none";
  }
});

//Add portugal Market
portugal.addEventListener("input", async function (e) {
  if (portugal.checked === true) {
    const data = await getActualService("PT");
    document.querySelector(".design_pt").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".lr_pt").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".pax_pt").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".business_pt").innerHTML = data[3].map(
      (service) => service
    );
    document.querySelector(".kitchen_pt").innerHTML = data[4].map(
      (service) => service
    );
    document.querySelector(".design1_bk_pt").classList.add(data[5][0]);
    document.querySelector(".design2_bk_pt").classList.add(data[5][1]);
    document.querySelector(".design3_bk_pt").classList.add(data[5][2]);
    document.querySelector(".design4_bk_pt").classList.add(data[5][3]);
    document.querySelector(".design5_bk_pt").classList.add(data[6][0]);
    document.querySelector(".design6_bk_pt").classList.add(data[6][1]);
    document.querySelector(".design7_bk_pt").classList.add(data[7][0]);
    document.querySelector(".design8_bk_pt").classList.add(data[7][1]);
    document.querySelector(".design9_bk_pt").classList.add(data[7][2]);
    document.querySelector(".design10_bk_pt").classList.add(data[8][0]);
    document.querySelector(".design11_bk_pt").classList.add(data[9][0]);
    document.querySelector(".design12_bk_pt").classList.add(data[9][1]);
    document.querySelector(".design13_bk_pt").classList.add(data[9][2]);
    getBookingData(
      "./JsonData/PT/PT_HOME_FURNISHING_BASIC_CUSTOMER.json",
      ".coworker-booking1-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking3-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_SEASONAL_CUSTOMER.json",
      ".coworker-booking4-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_LIVING_ROOM.json",
      ".coworker-booking5-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking6-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_WARDROBE.json",
      ".coworker-booking7-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_WARDROBE_CUSTOMER.json",
      ".coworker-booking8-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking9-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_BUSINESS_PLANNING.json",
      ".coworker-booking10-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking11-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking12-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking13-pt"
    );

    services_group.appendChild(document.querySelector(".portugal_services "));
    document.querySelector(".portugal_services ").style.display = "initial";
  }
  //Remove market when unchecked
  if (portugal.checked === false) {
    const removeElement = [
      ".coworker-booking1-pt",
      ".coworker-booking2-pt",
      ".coworker-booking3-pt",
      ".coworker-booking4-pt",
      ".coworker-booking5-pt",
      ".coworker-booking6-pt",
      ".coworker-booking7-pt",
      ".coworker-booking8-pt",
      ".coworker-booking9-pt",
      ".coworker-booking10-pt",
      ".coworker-booking11-pt",
      ".coworker-booking12-pt",
      ".coworker-booking13-pt",
      ".design1_bk_pt",
      ".design2_bk_pt",
      ".design3_bk_pt",
      ".design4_bk_pt",
      ".design5_bk_pt",
      ".design6_bk_pt",
      ".design7_bk_pt",
      ".design8_bk_pt",
      ".design9_bk_pt",
      ".design10_bk_pt",
      ".design11_bk_pt",
      ".design12_bk_pt",
      ".design13_bk_pt",
    ];

    removeClasslist(removeElement);
    document.querySelector(".portugal_services ").style.display = "none";
  }
});

//Netherland Market

netherland.addEventListener("input", async function (e) {
  if (netherland.checked === true) {
    const data = await getActualService("NL");
    const actualService = data[0].map((service) => service);
    document.querySelector(".actual_service_nl").innerHTML = actualService;
    document.querySelector(".customer_book_nl1").classList.add(data[1][0]);
    document.querySelector(".customer_book_nl2").classList.add(data[1][1]);
    getBookingData(
      "./JsonData/NL/NL_PLANNING_LIVING_ROOM.json",
      ".coworker-booking1-nl"
    );
    getBookingData(
      "./JsonData/NL/NL_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking2-nl"
    );
    services_group.appendChild(document.querySelector(".services_netherland"));
    document.querySelector(".services_netherland").style.display = "initial";
  }
  //Remove market when unchecked
  if (netherland.checked === false) {
    const removeElement = [
      ".customer_book_nl1",
      ".customer_book_nl2",
      ".coworker-booking1-nl",
      ".coworker-booking2-nl",
    ];
    removeClasslist(removeElement);
    document.querySelector(".services_netherland").style.display = "none";
  }
});

// Poland Market
poland.addEventListener("input", async function (e) {
  if (poland.checked === true) {
    const data = await getActualService("pl");

    document.querySelector(".design_pl").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".lr_pl").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".pax_pl").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".business_pl").innerHTML = data[3].map(
      (service) => service
    );
    document.querySelector(".smarthome_pl").innerHTML = data[4].map(
      (service) => service
    );
    document.querySelector(".cust_book_pl1").classList.add(data[5][0]);
    document.querySelector(".cust_book_pl2").classList.add(data[5][1]);
    document.querySelector(".cust_book_pl3").classList.add(data[5][2]);
    document.querySelector(".cust_book_pl4").classList.add(data[5][3]);
    document.querySelector(".cust_book_pl5").classList.add(data[5][4]);
    document.querySelector(".cust_book_pl6").classList.add(data[5][5]);
    document.querySelector(".cust_book_pl7").classList.add(data[6][0]);
    document.querySelector(".cust_book_pl8").classList.add(data[6][1]);
    document.querySelector(".cust_book_pl9").classList.add(data[7][0]);
    document.querySelector(".cust_book_pl10").classList.add(data[7][1]);
    document.querySelector(".cust_book_pl11").classList.add(data[8][0]);
    document.querySelector(".cust_book_pl12").classList.add(data[8][1]);
    document.querySelector(".cust_book_pl13").classList.add(data[8][2]);
    document.querySelector(".cust_book_pl14").classList.add(data[9][0]);
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_BASIC_CUSTOMER.json",
      ".coworker-booking2-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking3-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking4-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_COMPLETE_CUSTOMER.json",
      ".coworker-booking5-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking6-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_LIVING_ROOM.json",
      ".coworker-booking7-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking8-pl"
    );

    getBookingData(
      "./JsonData/PL/PL_PLANNING_WARDROBE.json",
      ".coworker-booking9-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking10-pl"
    );

    getBookingData(
      "./JsonData/PL/PL_DECORATION_BUSINESS.json",
      ".coworker-booking11-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_BUSINESS_PLANNING.json",
      ".coworker-booking12-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking13-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_HOME_SMART_REMOTE.json",
      ".coworker-booking14-pl"
    );

    services_group.appendChild(document.querySelector(".services_poland"));
    document.querySelector(".services_poland").style.display = "initial";
  }
  //Remove market when unchecked
  if (poland.checked === false) {
    const removeElement = [
      ".coworker-booking1-pl",
      ".coworker-booking2-pl",
      ".coworker-booking3-pl",
      ".coworker-booking4-pl",
      ".coworker-booking5-pl",
      ".coworker-booking6-pl",
      ".coworker-booking7-pl",
      ".coworker-booking8-pl",
      ".coworker-booking9-pl",
      ".coworker-booking10-pl",
      ".coworker-booking11-pl",
      ".coworker-booking12-pl",
      ".coworker-booking13-pl",
      ".coworker-booking14-pl",
      ".cust_book_pl1",
      ".cust_book_pl2",
      ".cust_book_pl3",
      ".cust_book_pl4",
      ".cust_book_pl5",
      ".cust_book_pl6",
      ".cust_book_pl7",
      ".cust_book_pl8",
      ".cust_book_pl9",
      ".cust_book_pl10",
      ".cust_book_pl11",
      ".cust_book_pl12",
      ".cust_book_pl13",
      ".cust_book_pl14",
    ];

    removeClasslist(removeElement);
    document.querySelector(".services_poland").style.display = "none";
  }
});

//UK Market
UK.addEventListener("input", async function (e) {
  if (UK.checked === true) {
    const data = await getActualService("GB");
    document.querySelector(".design_uk").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".lr_uk").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".bedroom_uk").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".business_uk").innerHTML = data[3].map(
      (service) => service
    );
    document.querySelector(".kitchen_uk").innerHTML = data[4].map(
      (service) => service
    );
    document.querySelector(".bdc_uk").innerHTML = data[5].map(
      (service) => service
    );
    document.querySelector(".cust_book_uk1").classList.add(data[6][0]);
    document.querySelector(".cust_book_uk2").classList.add(data[7][0]);
    document.querySelector(".cust_book_uk3").classList.add(data[7][1]);
    document.querySelector(".cust_book_uk4").classList.add(data[8][0]);
    document.querySelector(".cust_book_uk5").classList.add(data[8][1]);
    document.querySelector(".cust_book_uk6").classList.add(data[9][0]);
    document.querySelector(".cust_book_uk7").classList.add(data[10][0]);
    document.querySelector(".cust_book_uk8").classList.add(data[10][1]);
    document.querySelector(".cust_book_uk9").classList.add(data[10][2]);
    document.querySelector(".cust_book_uk10").classList.add(data[11][0]);

    getBookingData(
      "./JsonData/UK/UK_HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking1-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_LIVING_ROOM.json",
      ".coworker-booking2-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking3-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_WARDROBE.json",
      ".coworker-booking4-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking5-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking6-uk"
    );

    getBookingData(
      "./JsonData/UK/UK_VERIFY_PLANNING_AND_DRAWING.json",
      ".coworker-booking7-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_KITCHEN_STORE.json",
      ".coworker-booking8-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking9-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_INTERIOR_DESIGN_BUSINESS_CONSULTATION.json",
      ".coworker-booking10-uk"
    );
    services_group.appendChild(document.querySelector(".services_uk"));
    document.querySelector(".services_uk").style.display = "initial";
  }

  //Remove market when unchecked
  if (UK.checked === false) {
    const removeElement = [
      ".cust_book_uk1",
      ".cust_book_uk2",
      ".cust_book_uk3",
      ".cust_book_uk4",
      ".cust_book_uk5",
      ".cust_book_uk6",
      ".cust_book_uk7",
      ".cust_book_uk8",
      ".cust_book_uk9",
      ".cust_book_uk10",
      ".coworker-booking1-uk",
      ".coworker-booking2-uk",
      ".coworker-booking3-uk",
      ".coworker-booking4-uk",
      ".coworker-booking5-uk",
      ".coworker-booking6-uk",
      ".coworker-booking7-uk",
      ".coworker-booking8-uk",
      ".coworker-booking9-uk",
      ".coworker-booking10-uk",
    ];
    removeClasslist(removeElement);
    document.querySelector(".services_uk").style.display = "none";
  }
});

// Serbia Market
serbia.addEventListener("input", async function (e) {
  if (serbia.checked === true) {
    const data = await getActualService("rs");
    document.querySelector(".design_rs").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".kitchen_rs").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".bedroom_rs").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".business_rs").innerHTML = data[3].map(
      (service) => service
    );

    document.querySelector(".custBookRSDesign").classList.add(data[4][0]);
    document.querySelector(".custBookRSKitchen1").classList.add(data[5][0]);
    document.querySelector(".custBookRSKitchen2").classList.add(data[5][1]);
    document.querySelector(".custBookRSKitchen3").classList.add(data[5][2]);
    document.querySelector(".custBookRSKitchen4").classList.add(data[5][3]);
    document.querySelector(".custBookRSBedroom").classList.add(data[6][0]);
    document.querySelector(".custBookRSBusiness").classList.add(data[7][0]);

    getBookingData(
      "./JsonData/RS/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking1-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_CUSTOMER.json",
      ".coworker-booking2-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking3-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking4-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking5-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking6-rs"
    );
    getBookingData(
      "./JsonData/RS/INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking7-rs"
    );

    services_group.appendChild(document.querySelector(".services_serbia"));
    document.querySelector(".services_serbia").style.display = "initial";
  }
  //Remove market when unchecked
  if (serbia.checked === false) {
    const removeElement = [
      ".custBookRSDesign",
      ".custBookRSKitchen1",
      ".custBookRSKitchen2",
      ".custBookRSKitchen3",
      ".custBookRSKitchen4",
      ".custBookRSBedroom",
      ".custBookRSBusiness",
      ".coworker-booking1-rs",
      ".coworker-booking2-rs",
      ".coworker-booking3-rs",
      ".coworker-booking4-rs",
      ".coworker-booking5-rs",
      ".coworker-booking6-rs",
      ".coworker-booking7-rs",
    ];
    removeClasslist(removeElement);
    document.querySelector(".services_serbia").style.display = "none";
  }
});

finland.addEventListener("input", async function (e) {
  if (finland.checked === true) {
    const data = await getActualService("fi");

    document.querySelector(".design_fi").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".kitchen_fi").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".bedroom_fi").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".business_fi").innerHTML = data[3].map(
      (service) => service
    );
    document.querySelector(".bathroom_fi").innerHTML = data[4].map(
      (service) => service
    );
    document.querySelector(".trailer_fi").innerHTML = data[5].map(
      (service) => service
    );

    document.querySelector(".custBookFIDesign1").classList.add(data[6][0]);
    document.querySelector(".custBookFIDesign2").classList.add(data[6][1]);
    document.querySelector(".custBookFIDesign3").classList.add(data[6][2]);
    document.querySelector(".custBookFIDesign4").classList.add(data[6][3]);
    document.querySelector(".custBookFIKitchen1").classList.add(data[7][0]);
    document.querySelector(".custBookFIKitchen2").classList.add(data[7][1]);
    document.querySelector(".custBookFIKitchen3").classList.add(data[7][2]);
    document.querySelector(".custBookFIBedroom1").classList.add(data[8][0]);
    document.querySelector(".custBookFIBedroom2").classList.add(data[8][1]);
    document.querySelector(".custBookFIBusiness").classList.add(data[9][0]);
    document.querySelector(".custBookFIBathroom1").classList.add(data[10][0]);
    document.querySelector(".custBookFIBathroom2").classList.add(data[10][1]);
    document.querySelector(".custBookFITrailor").classList.add(data[11][0]);

    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-fi"
    );
    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-fi"
    );
    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking3-fi"
    );
    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking4-fi"
    );

    getBookingData(
      "./JsonData/FI/PLANNING_KITCHEN_CUSTOMER.json",
      ".coworker-booking5-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking6-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking7-fi"
    );

    getBookingData(
      "./JsonData/FI/PLANNING_WARDROBE.json",
      ".coworker-booking8-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking9-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking10-fi"
    );

    getBookingData(
      "./JsonData/FI/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking11-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_BATHROOM_STORE.json",
      ".coworker-booking12-fi"
    );

    getBookingData(
      "./JsonData/FI/RENT_A_TRAILER.json",
      ".coworker-booking13-fi"
    );

    services_group.appendChild(document.querySelector(".services_finland"));
    document.querySelector(".services_finland").style.display = "initial";
  }

  //Remove market when unchecked
  if (finland.checked === false) {
    const removeElement = [
      ".custBookFIDesign1",
      ".custBookFIDesign2",
      ".custBookFIDesign3",
      ".custBookFIDesign4",
      ".custBookFIKitchen1",
      ".custBookFIKitchen2",
      ".custBookFIKitchen3",
      ".custBookFIKitchen1",
      ".custBookFIKitchen2",
      ".custBookFIBedroom1",
      ".custBookFIBedroom2",
      ".custBookFIBusiness",
      ".custBookFIBathroom1",
      ".custBookFIBathroom2",
      ".custBookFITrailor",
    ];
    removeClasslist(removeElement);
    document.querySelector(".services_finland").style.display = "none";
  }
});

ireland.addEventListener("input", async function (e) {
  if (ireland.checked === true) {
    const data = await getActualService("ie");
    document.querySelector(".design_ie").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".bedroom_ie").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".lr_ie").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".custBookIEDesign").classList.add(data[3][0]);
    document.querySelector(".custBookIEBedroom1").classList.add(data[4][0]);
    document.querySelector(".custBookIEBedroom2").classList.add(data[4][1]);
    document.querySelector(".custBookIELr1").classList.add(data[5][0]);
    document.querySelector(".custBookIELr2").classList.add(data[5][1]);
    getBookingData(
      "./JsonData/IE/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking1-ie"
    );
    getBookingData(
      "./JsonData/IE/PLANNING_WARDROBE.json",
      ".coworker-booking2-ie"
    );
    getBookingData(
      "./JsonData/IE/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking3-ie"
    );
    getBookingData(
      "./JsonData/IE/PLANNING_LIVING_ROOM.json",
      ".coworker-booking4-ie"
    );
    getBookingData(
      "./JsonData/IE/PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking5-ie"
    );

    if (services_group.hasChildNodes(".services_ireland")) {
      services_group.appendChild(document.querySelector(".services_ireland"));
      document.querySelector(".services_ireland").style.display = "initial";
    }
  }
  //Remove market when unchecked
  if (ireland.checked === false) {
    const removeElement = [
      ".custBookIEDesign",
      ".custBookIEBedroom1",
      ".custBookIEBedroom2",
      ".custBookIELr1",
      ".custBookIELr2",
      ".coworker-booking1-ie",
      ".coworker-booking2-ie",
      ".coworker-booking3-ie",
      ".coworker-booking4-ie",
      ".coworker-booking5-ie",
    ];

    removeClasslist(removeElement);

    document.querySelector(".services_ireland").style.display = "none";
  }
});

japan.addEventListener("input", async function (e) {
  if (japan.checked === true) {
    const data = await getActualService("jp");
    document.querySelector(".design_jp").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".pax_jp").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".kitchen_jp").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".business_jp").innerHTML = data[3].map(
      (service) => service
    );
    document.querySelector(".businessDC_jp").innerHTML = data[4].map(
      (service) => service
    );
    document.querySelector(".businessID_jp").innerHTML = data[5].map(
      (service) => service
    );
    document.querySelector(".bathroom_jp").innerHTML = data[6].map(
      (service) => service
    );
    document.querySelector(".bedroom_jp").innerHTML = data[7].map(
      (service) => service
    );
    document.querySelector(".custBookJpDesign1").classList.add(data[8][0]);
    document.querySelector(".custBookJpDesign2").classList.add(data[8][1]);
    document.querySelector(".custBookJpPax1").classList.add(data[9][0]);
    document.querySelector(".custBookJpPax2").classList.add(data[9][1]);
    document.querySelector(".custBookJpKitchen1").classList.add(data[10][0]);
    document.querySelector(".custBookJpKitchen2").classList.add(data[10][1]);
    document.querySelector(".custBookJpKitchen3").classList.add(data[10][2]);
    document.querySelector(".custBookJpKitchen4").classList.add(data[10][3]);
    document.querySelector(".custBookJpBusiness1").classList.add(data[11][0]);
    document.querySelector(".custBookJpBusiness2").classList.add(data[11][1]);
    document.querySelector(".custBookJpBusinessID1").classList.add(data[12][0]);
    document.querySelector(".custBookJpBusinessID2").classList.add(data[12][1]);
    document.querySelector(".custBookJpBusinessDC1").classList.add(data[13][0]);
    document.querySelector(".custBookJpBusinessDC2").classList.add(data[13][1]);
    document.querySelector(".custBookJpBathroom1").classList.add(data[14][0]);
    document.querySelector(".custBookJpBedroom1").classList.add(data[15][0]);

    getBookingData(
      "./JsonData/JP/HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking1-jp"
    );
    getBookingData(
      "./JsonData/JP/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking2-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_WARDROBE.json",
      ".coworker-booking3-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking4-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking5-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking6-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_BUSINESS_ADVANCED_REMOTE.json",
      ".coworker-booking8-jp"
    );
    getBookingData(
      "./JsonData/JP/BUSINESS_PLANNING.json",
      ".coworker-booking9-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking10-jp"
    );
    getBookingData(
      "./JsonData/JP/INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking11-jp"
    );
    getBookingData(
      "./JsonData/JP/ID_BUSINESS_REMOTE.json",
      ".coworker-booking12-jp"
    );
    getBookingData(
      "./JsonData/JP/INTERIOR_DESIGN_BUSINESS_CONSULTATION.json",
      ".coworker-booking13-jp"
    );
    getBookingData(
      "./JsonData/JP/INTERIOR_DESIGN_BUSINESS_CONSULTATION_REMOTE.json",
      ".coworker-booking14-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking15-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_SLEEP_REMOTE.json",
      ".coworker-booking16-jp"
    );
    getBookingData(
      "./JsonData/JP/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking7-jp"
    );

    services_group.appendChild(document.querySelector(".services_japan"));

    document.querySelector(".services_japan").style.display = "initial";
  }
  //Remove market when unchecked
  if (japan.checked === false) {
    const removeElement = [
      ".custBookJpDesign1",
      ".custBookJpDesign2",
      ".custBookJpPax1",
      ".custBookJpPax2",
      ".custBookJpKitchen1",
      ".custBookJpKitchen2",
      ".custBookJpKitchen3",
      ".custBookJpKitchen4",
      ".custBookJpBusiness1",
      ".custBookJpBusiness2",
      ".custBookJpBusinessID1",
      ".custBookJpBusinessID2",
      ".custBookJpBusinessDC1",
      ".custBookJpBusinessDC2",
      ".custBookJpBathroom1",
      ".custBookJpBedroom1",
    ];

    removeClasslist(removeElement);
    document.querySelector(".services_japan").style.display = "none";
  }
});

switzerland.addEventListener("input", async function (e) {
  if (switzerland.checked === true) {
    const data = await getActualService("ch");
    document.querySelector(".design_ch").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".business_ch").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".custBookCHDesign1").classList.add(data[2][0]);
    document.querySelector(".custBookCHDesign2").classList.add(data[2][1]);
    document.querySelector(".custBookCHDesign3").classList.add(data[2][2]);
    document.querySelector(".custBookCHDesign4").classList.add(data[2][3]);
    document.querySelector(".custBookCHBusiness1").classList.add(data[3][0]);
    document.querySelector(".custBookCHBusiness2").classList.add(data[3][1]);
    getBookingData(
      "./JsonData/CH/HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-ch"
    );
    getBookingData(
      "./JsonData/CH/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-ch"
    );
    getBookingData(
      "./JsonData/CH/HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking3-ch"
    );
    getBookingData(
      "./JsonData/CH/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking4-ch"
    );
    getBookingData(
      "./JsonData/CH/BUSINESS_PLANNING.json",
      ".coworker-booking5-ch"
    );
    getBookingData(
      "./JsonData/CH/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking6-ch"
    );

    services_group.appendChild(document.querySelector(".services_switzerland"));
    document.querySelector(".services_switzerland").style.display = "initial";
  }

  //Remove market when unchecked
  if (switzerland.checked === false) {
    const removeElement = [
      ".custBookCHDesign1",
      ".custBookCHDesign2",
      ".custBookCHDesign3",
      ".custBookCHDesign4",
      ".custBookCHBusiness1",
      ".custBookCHBusiness2",
    ];

    removeClasslist(removeElement);

    document.querySelector(".services_switzerland").style.display = "none";
  }
});

sweden.addEventListener("input", async function (e) {
  const data = await getActualService("se");
  document.querySelector(".design_se").innerHTML = data[0].map(
    (service) => service
  );
  document.querySelector(".pax_se").innerHTML = data[1].map(
    (service) => service
  );
  document.querySelector(".Workspace_se").innerHTML = data[2].map(
    (service) => service
  );

  document.querySelector(".bathroom_se").innerHTML = data[3].map(
    (service) => service
  );
  document.querySelector(".bedroom_se").innerHTML = data[4].map(
    (service) => service
  );
  document.querySelector(".sofa_se").innerHTML = data[5].map(
    (service) => service
  );
  document.querySelector(".seasonal_se").innerHTML = data[6].map(
    (service) => service
  );
  document.querySelector(".lr_se").innerHTML = data[7].map(
    (service) => service
  );
  document.querySelector(".custBookSEDesign1").classList.add(data[8][0]);
  document.querySelector(".custBookSEDesign2").classList.add(data[8][1]);
  document.querySelector(".custBookSEPax1").classList.add(data[9][0]);
  document.querySelector(".custBookSEPax2").classList.add(data[9][1]);
  document.querySelector(".custBookSEWorkspace1").classList.add(data[10][0]);
  document.querySelector(".custBookSEWorkspace2").classList.add(data[10][1]);
  document.querySelector(".custBookSEBathroom1").classList.add(data[11][0]);
  document.querySelector(".custBookSEBathroom2").classList.add(data[11][1]);
  document.querySelector(".custBookSEBedroom1").classList.add(data[12][0]);
  document.querySelector(".custBookSEBedroom2").classList.add(data[12][1]);
  document.querySelector(".custBookSESofa1").classList.add(data[13][0]);
  document.querySelector(".custBookSESofa2").classList.add(data[13][1]);
  document.querySelector(".custBookSESeasonal1").classList.add(data[14][0]);
  document.querySelector(".custBookSESeasonal2").classList.add(data[14][1]);
  document.querySelector(".custBookSELr1").classList.add(data[15][0]);
  document.querySelector(".custBookSELr2").classList.add(data[15][1]);
  if (sweden.checked === true) {
    getBookingData(
      "./JsonData/SE/HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-se"
    );
    getBookingData(
      "./JsonData/SE/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_WARDROBE.json",
      ".coworker-booking3-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking4-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_WORKSPACES.json",
      ".coworker-booking5-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_WORKSPACES_REMOTE.json",
      ".coworker-booking6-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking7-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_BATHROOM_STORE.json",
      ".coworker-booking8-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SLEEP.json",
      ".coworker-booking9-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SLEEP_REMOTE.json",
      ".coworker-booking10-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SOFA.json",
      ".coworker-booking11-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SOFA_REMOTE.json",
      ".coworker-booking12-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SEASONAL.json",
      ".coworker-booking13-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_SEASONAL_REMOTE.json",
      ".coworker-booking14-se"
    );

    getBookingData(
      "./JsonData/SE/PLANNING_LIVING_ROOM.json",
      ".coworker-booking15-se"
    );
    getBookingData(
      "./JsonData/SE/PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking16-se"
    );

    services_group.appendChild(document.querySelector(".services_sweden"));
    document.querySelector(".services_sweden").style.display = "initial";
  }

  //Remove market when unchecked
  if (sweden.checked === false) {
    const removeElement = [
      ".custBookSEDesign1",
      ".custBookSEDesign2",
      ".custBookSEPax1",
      ".custBookSEPax2",
      ".custBookSEWorkspace1",
      ".custBookSEWorkspace2",
      ".custBookSEBathroom1",
      ".custBookSEBathroom2",
      ".custBookSEBedroom1",
      ".custBookSESofa1",
      ".custBookSESofa2",
      ".custBookSESeasonal1",
      ".custBookSESeasonal2",
      ".custBookSELr1",
      ".custBookSELr2",
    ];

    removeClasslist(removeElement);

    document.querySelector(".services_sweden").style.display = "none";
  }
});

belgium.addEventListener("input", async function (e) {
  if (belgium.checked === true) {
    const data = await getActualService("be");
    document.querySelector(".pax_be").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".business_be").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".bathroom_be").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".lr_be").innerHTML = data[3].map(
      (service) => service
    );
    document.querySelector(".kitchen_be").innerHTML = data[4].map(
      (service) => service
    );
    document.querySelector(".custBookBEPax").classList.add(data[5][0]);
    document.querySelector(".custBookBEBusiness1").classList.add(data[6][0]);
    document.querySelector(".custBookBEBusiness2").classList.add(data[6][1]);
    document.querySelector(".custBookBEBathroom").classList.add(data[7][0]);
    document.querySelector(".custBookBELr").classList.add(data[8][0]);
    document.querySelector(".custBookBEKitchen1").classList.add(data[9][0]);
    document.querySelector(".custBookBEKitchen2").classList.add(data[9][1]);
    getBookingData(
      "./JsonData/BE/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking1-be"
    );
    getBookingData(
      "./JsonData/BE/BUSINESS_PLANNING.json",
      ".coworker-booking2-be"
    );
    getBookingData(
      "./JsonData/BE/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking3-be"
    );
    getBookingData(
      "./JsonData/BE/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking4-be"
    );
    getBookingData(
      "./JsonData/BE/PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking5-be"
    );
    getBookingData(
      "./JsonData/BE/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking6-be"
    );
    getBookingData(
      "./JsonData/BE/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking7-be"
    );

    services_group.appendChild(document.querySelector(".services_belgium"));
    document.querySelector(".services_belgium").style.display = "initial";
  }

  //Remove market when unchecked
  if (belgium.checked === false) {
    const removeElement = [
      ".custBookBEPax",
      ".custBookBEBusiness1",
      ".custBookBEBusiness1",
      ".custBookBEBathroom",
      ".custBookBELr",
      ".custBookBEKitchen1",
      ".custBookBEKitchen2",
    ];
    removeClasslist(removeElement);
    document.querySelector(".services_belgium").style.display = "none";
  }
});

korea.addEventListener("input", async function (e) {
  if (korea.checked === true) {
    const data = await getActualService("kr");
    document.querySelector(".design_kr").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".lr_kr").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".kitchen_kr").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".business_kr").innerHTML = data[3].map(
      (service) => service + "\n"
    );
    document.querySelector(".custBookKRDesign1").classList.add(data[4][0]);
    document.querySelector(".custBookKRDesign2").classList.add(data[4][1]);
    document.querySelector(".custBookKRDesign3").classList.add(data[4][2]);
    document.querySelector(".custBookKRLr").classList.add(data[5][0]);

    document.querySelector(".custBookKRKitchen1").classList.add(data[6][0]);
    document.querySelector(".custBookKRKitchen2").classList.add(data[6][1]);
    document.querySelector(".custBookKRKitchen3").classList.add(data[6][2]);
    document.querySelector(".custBookKRKitchen4").classList.add(data[6][3]);

    document.querySelector(".custBookKRBusiness1").classList.add(data[7][0]);
    document.querySelector(".custBookKRBusiness2").classList.add(data[7][1]);
    document.querySelector(".custBookKRBusiness3").classList.add(data[7][2]);
    getBookingData(
      "./JsonData/KR/INTERIOR_DESIGN.json",
      ".coworker-booking1-kr"
    );
    getBookingData(
      "./JsonData/KR/HOME_FURNISHING_BASIC.json",
      ".coworker-booking2-kr"
    );
    getBookingData(
      "./JsonData/KR/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking3-kr"
    );
    getBookingData(
      "./JsonData/KR/PLANNING_LIVING_ROOM.json",
      ".coworker-booking4-kr"
    );
    getBookingData(
      "./JsonData/KR/VERIFY_PLANNING_AND_DRAWING.json",
      ".coworker-booking5-kr"
    );
    getBookingData(
      "./JsonData/KR/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking6-kr"
    );
    getBookingData(
      "./JsonData/KR/KITCHEN_INSTALLATION_QUOTATION.json",
      ".coworker-booking7-kr"
    );
    getBookingData(
      "./JsonData/KR/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking8-kr"
    );
    getBookingData(
      "./JsonData/KR/BUSINESS_PLANNING.json",
      ".coworker-booking9-kr"
    );
    getBookingData(
      "./JsonData/KR/INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking10-kr"
    );
    getBookingData(
      "./JsonData/KR/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking11-kr"
    );

    services_group.appendChild(document.querySelector(".services_korea"));
    document.querySelector(".services_korea").style.display = "initial";
  }

  //Remove market when unchecked
  if (korea.checked === false) {
    const removeElement = [
      ".custBookKRDesign1",
      ".custBookKRDesign2",
      ".custBookKRDesign3",

      ".custBookKRLr",
      ".custBookKRKitchen1",
      ".custBookKRKitchen2",
      ".custBookKRKitchen3",
      ".custBookKRKitchen4",
      ".custBookKRBusiness1",
      ".custBookKRBusiness2",
      ".custBookKRBusiness3",
    ];
    removeClasslist(removeElement);

    document.querySelector(".services_korea").style.display = "none";
  }
});

australia.addEventListener("input", async function (e) {
  if (australia.checked === true) {
    const data = await getActualService("AU");
    const actualService = data[0].map((service) => service);
    document.querySelector(".actual_service").innerHTML = actualService;
    document.querySelector(".customer_book_au1").classList.add(data[1][0]);
    document.querySelector(".customer_book_au2").classList.add(data[1][1]);

    getBookingData(
      "./JsonData/AU/BUSINESS_PLANNING.json",
      ".coworker-booking1-au"
    );
    getBookingData(
      "./JsonData/AU/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking2-au"
    );

    services_group.appendChild(document.querySelector(".services_australia"));
    document.querySelector(".services_australia").style.display = "initial";
  }

  //Remove market when unchecked
  if (australia.checked === false) {
    const removeElement = [
      ".customer_book_au1",
      ".customer_book_au2",
      ".coworker-booking1-au",
      ".coworker-booking2-au",
    ];
    removeClasslist(removeElement);
    document.querySelector(".services_australia").style.display = "none";
  }
});

canada.addEventListener("input", async function (e) {
  if (canada.checked === true) {
    const data = await getActualService("ca");
    document.querySelector(".design_ca").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".lr_ca").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".kitchen_ca").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".business_ca").innerHTML = data[3].map(
      (service) => service + "\n"
    );
    document.querySelector(".bathroom_ca").innerHTML = data[4].map(
      (service) => service + "\n"
    );
    document.querySelector(".bedroom_ca").innerHTML = data[5].map(
      (service) => service + "\n"
    );
    document.querySelector(".custBookCADesign1").classList.add(data[6][0]);
    document.querySelector(".custBookCADesign2").classList.add(data[6][1]);
    document.querySelector(".custBookCADesign3").classList.add(data[6][2]);
    document.querySelector(".custBookCADesign4").classList.add(data[6][3]);
    document.querySelector(".custBookCALr").classList.add(data[7][0]);

    document.querySelector(".custBookCAKitchen1").classList.add(data[8][0]);
    document.querySelector(".custBookCAKitchen2").classList.add(data[8][1]);

    document.querySelector(".custBookCABusiness1").classList.add(data[9][0]);
    document.querySelector(".custBookCABusiness2").classList.add(data[9][1]);
    document.querySelector(".custBookCABusiness3").classList.add(data[9][2]);
    document.querySelector(".custBookCABusiness4").classList.add(data[9][3]);
    document.querySelector(".custBookCABathroom").classList.add(data[10][0]);
    document.querySelector(".custBookCABedroom1").classList.add(data[11][0]);
    document.querySelector(".custBookCABedroom2").classList.add(data[11][1]);
    document.querySelector(".custBookCABedroom3").classList.add(data[11][2]);
    document.querySelector(".custBookCABedroom4").classList.add(data[11][3]);

    getBookingData(
      "./JsonData/CA/HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-ca"
    );
    getBookingData(
      "./JsonData/CA/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-ca"
    );
    getBookingData(
      "./JsonData/CA/HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking3-ca"
    );
    getBookingData(
      "./JsonData/CA/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking4-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking5-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking6-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking7-ca"
    );
    getBookingData(
      "./JsonData/CA/BUSINESS_PLANNING.json",
      ".coworker-booking8-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_BUSINESS_ADVANCED.json",
      ".coworker-booking9-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_BUSINESS_ADVANCED_REMOTE.json",
      ".coworker-booking10-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking11-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking11-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking12-ca"
    );

    getBookingData(
      "./JsonData/CA/PLANNING_WARDROBE.json",
      ".coworker-booking13-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking14-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_SLEEP.json",
      ".coworker-booking15-ca"
    );
    getBookingData(
      "./JsonData/CA/PLANNING_SLEEP_REMOTE.json",
      ".coworker-booking16-ca"
    );

    services_group.appendChild(document.querySelector(".services_canada"));
    document.querySelector(".services_canada").style.display = "initial";
  }

  //Remove market when unchecked
  if (canada.checked === false) {
    const removeElement = [
      ".custBookCADesign1",
      ".custBookCADesign2",
      ".custBookCADesign3",
      ".custBookCADesign4",
      ".custBookCALr",
      ".custBookCAKitchen1",
      ".custBookCAKitchen2",
      ".custBookCABusiness1",
      ".custBookCABusiness2",
      ".custBookCABusiness3",
      ".custBookCABusiness4",
      ".custBookCABathroom",
      ".custBookCABedroom1",
      ".custBookCABedroom2",
      ".custBookCABedroom3",
      ".custBookCABedroom4",
    ];
    removeClasslist(removeElement);

    document.querySelector(".services_canada").style.display = "none";
  }
});

slovenia.addEventListener("input", async function (e) {
  if (slovenia.checked === true) {
    const data = await getActualService("SI");

    document.querySelector(".kitchen_si").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".bedroom_si").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".custBookSIKitchen1").classList.add(data[2][0]);
    document.querySelector(".custBookSIKitchen2").classList.add(data[2][1]);
    document.querySelector(".custBookSIKitchen3").classList.add(data[2][2]);
    document.querySelector(".custBookSIBedroom").classList.add(data[3][0]);
    getBookingData(
      "./JsonData/SI/PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking1-si"
    );
    getBookingData(
      "./JsonData/SI/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking2-si"
    );
    getBookingData(
      "./JsonData/SI/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking3-si"
    );
    getBookingData(
      "./JsonData/SI/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking4-si"
    );

    services_group.appendChild(document.querySelector(".services_slovenia"));
    document.querySelector(".services_slovenia").style.display = "initial";
  }

  //Remove market when unchecked
  if (slovenia.checked === false) {
    const removeElement = [
      ".custBookSIKitchen1",
      ".custBookSIKitchen2",
      ".custBookSIKitchen3",
      ".custBookSIBedroom",
    ];

    removeClasslist(removeElement);

    document.querySelector(".services_slovenia").style.display = "none";
  }
});

spain.addEventListener("input", async function (e) {
  if (spain.checked === true) {
    const data = await getActualService("es");
    document.querySelector(".design_es").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".business_es").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".businessID_es").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".businessDC_es").innerHTML = data[3].map(
      (service) => service
    );

    document.querySelector(".bathroom_es").innerHTML = data[4].map(
      (service) => service
    );

    document.querySelector(".custBookESDesign1").classList.add(data[5][0]);
    document.querySelector(".custBookESDesign2").classList.add(data[5][1]);
    document.querySelector(".custBookESDesign3").classList.add(data[5][2]);
    document.querySelector(".custBookESDesign4").classList.add(data[5][3]);

    document.querySelector(".custBookESBusiness1").classList.add(data[6][0]);
    document.querySelector(".custBookESBusiness2").classList.add(data[6][1]);
    document.querySelector(".custBookESBusiness3").classList.add(data[6][2]);
    document.querySelector(".custBookESBusiness4").classList.add(data[6][3]);

    document.querySelector(".custBookESBusinessID1").classList.add(data[7][0]);
    document.querySelector(".custBookESBusinessID2").classList.add(data[7][1]);
    document.querySelector(".custBookESBusinessDC").classList.add(data[8][0]);

    document.querySelector(".custBookESBathroom1").classList.add(data[9][0]);
    document.querySelector(".custBookESBathroom2").classList.add(data[9][1]);
    getBookingData(
      "./JsonData/ES/HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-es"
    );
    getBookingData(
      "./JsonData/ES/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-es"
    );
    getBookingData(
      "./JsonData/ES/HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking3-es"
    );
    getBookingData(
      "./JsonData/ES/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking4-es"
    );
    getBookingData(
      "./JsonData/ES/INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking5-es"
    );
    getBookingData(
      "./JsonData/ES/ID_BUSINESS_REMOTE.json",
      ".coworker-booking6-es"
    );
    getBookingData(
      "./JsonData/ES/PLANNING_BUSINESS_ADVANCED.json",
      ".coworker-booking7-es"
    );
    getBookingData(
      "./JsonData/ES/PLANNING_BUSINESS_ADVANCED_REMOTE.json",
      ".coworker-booking8-es"
    );
    getBookingData(
      "./JsonData/ES/ID_BUSINESS_REMOTE_MEDIUM.json",
      ".coworker-booking9-es"
    );
    getBookingData(
      "./JsonData/ES/ID_BUSINESS_REMOTE_MEDIUM.json",
      ".coworker-booking10-es"
    );
    getBookingData(
      "./JsonData/ES/INTERIOR_DESIGN_BUSINESS_CONSULTATION_REMOTE.json",
      ".coworker-booking11-es"
    );
    getBookingData(
      "./JsonData/ES/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking12-es"
    );
    getBookingData(
      "./JsonData/ES/PLANNING_BATHROOM_STORE.json",
      ".coworker-booking13-es"
    );
    services_group.appendChild(document.querySelector(".services_spain"));
    document.querySelector(".services_spain").style.display = "initial";
  }

  //Remove market when unchecked
  if (spain.checked === false) {
    const removeElement = [
      ".custBookESDesign1",
      ".custBookESDesign2",
      ".custBookESDesign3",
      ".custBookESDesign4",
      ".custBookESBusiness1",
      ".custBookESBusiness2",
      ".custBookESBusiness3",
      ".custBookESBusiness4",
      ".custBookESBusinessID1",
      ".custBookESBusinessID2",
      ".custBookESBusinessDC",
      ".custBookJpBusinessDC2",
      ".custBookESBathroom1",
      ".custBookESBathroom2",
    ];
    removeClasslist(removeElement);

    document.querySelector(".services_spain").style.display = "none";
  }
});
croatia.addEventListener("input", async function (e) {
  if (croatia.checked === true) {
    const data = await getActualService("HR");

    document.querySelector(".bathroom_hr").innerHTML = data[0].map(
      (service) => service
    );
    document.querySelector(".kitchen_hr").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".business_hr").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".bedroom_hr").innerHTML = data[3].map(
      (service) => service
    );
    document.querySelector(".custBookHRBathroom1").classList.add(data[4][0]);
    document.querySelector(".custBookHRBathroom2").classList.add(data[4][1]);
    document.querySelector(".custBookHRKitchen1").classList.add(data[5][0]);
    document.querySelector(".custBookHRKitchen2").classList.add(data[5][1]);
    document.querySelector(".custBookHRKitchen3").classList.add(data[5][2]);
    document.querySelector(".custBookHRKitchen4").classList.add(data[5][3]);
    document.querySelector(".custBookHRBusiness").classList.add(data[6][0]);
    document.querySelector(".custBookHRBedroom1").classList.add(data[7][0]);
    document.querySelector(".custBookHRBedroom2").classList.add(data[7][0]);
    getBookingData(
      "./JsonData/HR/PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking1-hr"
    );
    getBookingData(
      "./JsonData/HR/PLANNING_BATHROOM_STORE.json",
      ".coworker-booking2-hr"
    );
    getBookingData("./JsonData/HR/HOME_PLANNING.json", ".coworker-booking3-hr");
    getBookingData(
      "./JsonData/HR/PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking4-hr"
    );
    getBookingData(
      "./JsonData/HR/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking5-hr"
    );
    getBookingData(
      "./JsonData/HR/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking6-hr"
    );
    getBookingData(
      "./JsonData/HR/BUSINESS_PLANNING.json",
      ".coworker-booking7-hr"
    );
    getBookingData(
      "./JsonData/HR/PLANNING_WARDROBE.json",
      ".coworker-booking8-hr"
    );
    getBookingData(
      "./JsonData/HR/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking9-hr"
    );

    services_group.appendChild(document.querySelector(".services_croatia"));
    document.querySelector(".services_croatia").style.display = "initial";
  }

  //Remove market when unchecked
  if (croatia.checked === false) {
    const removeElement = [
      ".custBookHRBathroom1",
      ".custBookHRBathroom2",
      ".custBookHRKitchen1",
      ".custBookHRKitchen2",
      ".custBookHRKitchen3",
      ".custBookHRKitchen4",
      ".custBookHRBusiness",
      ".custBookHRBedroom1",
      ".custBookHRBedroom2",
    ];

    removeClasslist(removeElement);

    document.querySelector(".services_croatia").style.display = "none";
  }
});

us.addEventListener("input", async function (e) {
  if (us.checked === true) {
    const data = await getActualService("US");
    document.querySelector(".bedroom_us").innerHTML = data[0].map(
      (service) => service
    );

    document.querySelector(".lr_us").innerHTML = data[1].map(
      (service) => service
    );
    document.querySelector(".kitchen_us").innerHTML = data[2].map(
      (service) => service
    );
    document.querySelector(".business_us").innerHTML = data[3].map(
      (service) => service
    );

    document.querySelector(".custBookUSBedroom").classList.add(data[4][0]);
    document.querySelector(".custBookUSLr").classList.add(data[5][0]);
    document.querySelector(".custBookUSKitchen1").classList.add(data[6][0]);
    document.querySelector(".custBookUSKitchen2").classList.add(data[6][1]);
    document.querySelector(".custBookUSKitchen3").classList.add(data[6][2]);

    document.querySelector(".custBookUSBusiness").classList.add(data[7][0]);

    getBookingData(
      "./JsonData/US/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking1-us"
    );
    getBookingData(
      "./JsonData/US/PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking2-us"
    );
    getBookingData(
      "./JsonData/US/VERIFY_PLANNING_AND_DRAWING.json",
      ".coworker-booking3-us"
    );
    getBookingData(
      "./JsonData/US/PLANNING_KITCHEN_STORE.json",
      ".coworker-booking4-us"
    );
    getBookingData(
      "./JsonData/US/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking5-us"
    );
    getBookingData(
      "./JsonData/US/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking6-us"
    );

    services_group.appendChild(document.querySelector(".services_usa"));
    document.querySelector(".services_usa").style.display = "initial";
  }

  //Remove market when unchecked
  if (us.checked === false) {
    const removeElement = [
      ".custBookUSBedroom",
      ".custBookUSLr",
      ".custBookUSKitchen1",
      ".custBookUSKitchen2",
      ".custBookUSKitchen3",
      ".custBookUSBusiness",
    ];

    removeClasslist(removeElement);

    document.querySelector(".services_usa").style.display = "none";
  }
});
