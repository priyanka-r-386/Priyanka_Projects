const axios = require("axios");
const { response } = require("express");
let data_services = [];

function getdata() {
  function getServiceData(service, pinCode, language) {
    return new Promise((resolve, reject) => {
      axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/servicesbygroup/${pinCode}/${service}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((response) => {
          resolve(response);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }
  return { getServiceData };
}

module.exports = getdata();
