const express = require("express");
const chalk = require("chalk");
const path = require("path");
const app = express();
const { response } = require("express");
const { debug } = require("console");
const indiaMarket = require("./All Markets/indianMarket");
const denmarkMarket = require("./All Markets/denmarkMarket");
const polandMarket = require("./All Markets/polandMarket");
const portugalMarket = require("./All Markets/portugalMarket");
const netherlandMarket = require("./All Markets/netherlandMarket");
const ukMarket = require("./All Markets/UKMarket");
const norwayMarket = require("./All Markets/norwayMarket");
const serbiaMarket = require("./All Markets/serbiaMarket");
const finlandMarket = require("./All Markets/finlandMarket");
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, "/public/")));

app.set("views", "./src/views");
app.set("view engine", "ejs");

app.get(
  "/",
  indiaMarket.getDesignIndia(),
  indiaMarket.getLRIndia(),
  indiaMarket.getPaxIndia(),
  denmarkMarket.getDesignDenmark(),
  denmarkMarket.getBusinessDenmark(),
  denmarkMarket.getBathroomDenmark(),
  polandMarket.getDesignPoland(),
  polandMarket.getPaxPoland(),
  polandMarket.getLRPoland(),
  polandMarket.getBusinessPoland(),
  polandMarket.getSmartHomePoland(),
  portugalMarket.getBusinessPortugal(),
  portugalMarket.getDesignPortugal(),
  portugalMarket.getKitchenPortugal(),
  portugalMarket.getLRPortugal(),
  portugalMarket.getPaxPortugal(),
  netherlandMarket.getLRNetherland(),
  ukMarket.getBedroomUK(),
  ukMarket.getBusinessConsultationUK(),
  ukMarket.getDesignUK(),
  ukMarket.getKitchenUK(),
  ukMarket.getLRUK(),
  ukMarket.getBusinessUK(),
  norwayMarket.getBathroomNorway(),
  norwayMarket.getBusinessNorway(),
  norwayMarket.getDesignNorway(),
  norwayMarket.getKitchenNorway(),
  norwayMarket.getPaxNorway(),
  serbiaMarket.getBedroomSerbia(),
  serbiaMarket.getBusinessSerbia(),
  serbiaMarket.getDesignSerbia(),
  serbiaMarket.getKitchenSerbia(),
  finlandMarket.getBathroomFinland(),
  finlandMarket.getBedroomFinland(),
  finlandMarket.getBusinessFinland(),
  finlandMarket.getKitchenFinland(),
  finlandMarket.getDesignFinland(),
  finlandMarket.getLRFinland(),
  finlandMarket.getTrailorFinland(),

  (req, res) => {
    res.render("index", {
      design_in: actual_service,
      lr_in: lr_service,
      pax_in: pax_service,
      design_dk: design_dk,
      business_dk: business_dk,
      bathroom_dk: bathroom_dk,
      design_pl: design_pl,
      pax_pl: pax_pl,
      lr_pl: lr_pl,
      business_pl: business_pl,
      sh_pl: sh_pl,
      design_pt: design_pt,
      lr_pt: lr_pt,
      pax_pt: pax_pt,
      kitchen_pt: kitchen_pt,
      business_pt: business_pt,
      lr_nl: lr_nl,
      design_uk: design_uk,
      lr_uk: lr_uk,
      business_uk: business_uk,
      bedroom_uk: bedroom_uk,
      kitchen_uk: kitchen_uk,
      business_consultation_uk: business_consultation_uk,
      design_no: design_no,
      pax_no: pax_no,
      kitchen_no: kitchen_no,
      bathroom_no: bathroom_no,
      business_no: business_no,
      bedroom_sr: bedroom_sr,
      design_sr: design_sr,
      kitchen_sr: kitchen_sr,
      business_sr: business_sr,
      bathroom_fl: bathroom_fl,
      business_fl: business_fl,
      bedroom_fl: bedroom_fl,
      design_fl: design_fl,
      kitchen_fl: kitchen_fl,
      business_fl: business_fl,
      trailor_fl: trailor_fl,
    });
  }
);

app.listen(PORT, () => {
  console.log(`listening to port ${chalk.green(PORT)}`);
});
