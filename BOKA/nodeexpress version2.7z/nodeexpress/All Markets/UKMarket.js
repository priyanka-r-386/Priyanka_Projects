const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = [
  "DESIGN",
  "BEDROOM",
  "LIVINGROOM",
  "BUSINESS",
  "KITCHEN",
  "BUSINESSDESIGNCONSULTATION",
];
const pinCode = "PE2 9ET";
const language = "en-gb";

function getDesignUK() {
  return async function getDData(req, res, next) {
    try {
      const design = await data_services.getServiceData(
        services[0],
        pinCode,
        language
      );

      const designServices = design.data.map(
        (sd) => sd.serviceProductId + "\n"
      );
      design_uk = designServices;
      next();
    } catch (error) {
      design_uk = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getBedroomUK() {
  return async function (req, res, next) {
    try {
      const bedroom = await data_services.getServiceData(
        services[1],
        pinCode,
        language
      );

      const bedroomServices = bedroom.data.map(
        (sd) => sd.serviceProductId + "\n"
      );
      bedroom_uk = bedroomServices;
      next();
    } catch (error) {
      bedroom_uk = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getLRUK() {
  return async function (req, res, next) {
    try {
      const lr = await data_services.getServiceData(
        services[2],
        pinCode,
        language
      );

      const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
      lr_uk = lrServices;
      next();
    } catch (error) {
      lr_uk = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getKitchenUK() {
  return async function (req, res, next) {
    try {
      const kitchen = await data_services.getServiceData(
        services[4],
        pinCode,
        language
      );

      const kitchenService = kitchen.data.map(
        (sd) => sd.serviceProductId + "\n"
      );
      kitchen_uk = kitchenService;
      next();
    } catch (error) {
      kitchen_uk = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getBusinessUK() {
  return async function (req, res, next) {
    try {
      const business = await data_services.getServiceData(
        services[3],
        pinCode,
        language
      );

      const businessService = business.data.map(
        (sd) => sd.serviceProductId + "\n"
      );
      business_uk = businessService;
      next();
    } catch (error) {
      business_uk = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getBusinessConsultationUK() {
  return async function (req, res, next) {
    try {
      const business = await data_services.getServiceData(
        services[5],
        pinCode,
        language
      );

      const businessService = business.data.map(
        (sd) => sd.serviceProductId + "\n"
      );
      business_consultation_uk = businessService;
      next();
    } catch (error) {
      business_consultation_uk = [
        error.response.status,
        error.response.statusText,
      ];
      next();
    }
  };
}
module.exports = {
  getLRUK,
  getDesignUK,
  getBedroomUK,
  getBusinessConsultationUK,
  getBusinessUK,
  getKitchenUK,
};
