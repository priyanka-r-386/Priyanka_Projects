const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = ["DESIGN", "PAX", "LIVINGROOM", "BUSINESS", "SMARTHOME"];
const pinCode = "03-286";
const language = "pl-pl";

function getDesignPoland() {
  return async function getDData(req, res, next) {
    try {
      const design = await data_services.getServiceData(
        services[0],
        pinCode,
        language
      );

      const designServices = design.data.map(
        (sd) => sd.serviceProductId + "\n"
      );
      design_pl = designServices;
      next();
    } catch (error) {
      design_pl = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getPaxPoland() {
  return async function (req, res, next) {
    try {
      const pax = await data_services.getServiceData(
        services[1],
        pinCode,
        language
      );

      const paxServices = pax.data.map((sd) => sd.serviceProductId + "\n");
      pax_pl = paxServices;
      next();
    } catch (error) {
      pax_pl = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getLRPoland() {
  return async function (req, res, next) {
    try {
      const lr = await data_services.getServiceData(
        services[2],
        pinCode,
        language
      );

      const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
      lr_pl = lrServices;
      next();
    } catch (error) {
      lr_pl = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getSmartHomePoland() {
  return async function (req, res, next) {
    try {
      const smarthome = await data_services.getServiceData(
        services[4],
        pinCode,
        language
      );

      const smartHomeService = smarthome.data.map(
        (sd) => sd.serviceProductId + "\n"
      );
      sh_pl = smartHomeService;
      next();
    } catch (error) {
      sh_pl = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getBusinessPoland() {
  return async function (req, res, next) {
    try {
      const business = await data_services.getServiceData(
        services[3],
        pinCode,
        language
      );

      const businessService = business.data.map(
        (sd) => sd.serviceProductId + "\n"
      );
      business_pl = businessService;
      next();
    } catch (error) {
      business_pl = [error.response.status, error.response.statusText];
      next();
    }
  };
}

module.exports = {
  getLRPoland,
  getDesignPoland,
  getPaxPoland,
  getBusinessPoland,
  getSmartHomePoland,
};
