const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = ["DESIGN", "PAX", "LIVINGROOM", "BUSINESS", "KITCHEN"];
const pinCode = "2330-060";
const language = "pt-pt";

function getDesignPortugal() {
  return async function getDData(req, res, next) {
    try {
      const design = await data_services.getServiceData(
        services[0],
        pinCode,
        language
      );

      const designServices = design.data.map(
        (sd) => sd.serviceProductId + "\n"
      );
      design_pt = designServices;
      next();
    } catch (error) {
      design_pt = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getPaxPortugal() {
  return async function (req, res, next) {
    try {
      const pax = await data_services.getServiceData("PAX", pinCode, language);

      const paxServices = pax.data.map((sd) => sd.serviceProductId + "\n");
      pax_pt = paxServices;
      next();
    } catch (error) {
      pax_pt = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getLRPortugal() {
  return async function (req, res, next) {
    try {
      const lr = await data_services.getServiceData(
        services[2],
        pinCode,
        language
      );

      const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
      lr_pt = lrServices;
      next();
    } catch (error) {
      lr_pt = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getKitchenPortugal() {
  return async function (req, res, next) {
    try {
      const kitchen = await data_services.getServiceData(
        services[4],
        pinCode,
        language
      );

      const kitchenService = kitchen.data.map(
        (sd) => sd.serviceProductId + "\n"
      );
      kitchen_pt = kitchenService;
      next();
    } catch (error) {
      kitchen_pt = [error.response.status, error.response.statusText];
      next();
    }
  };
}

function getBusinessPortugal() {
  return async function (req, res, next) {
    try {
      const business = await data_services.getServiceData(
        services[3],
        pinCode,
        language
      );

      const businessService = business.data.map(
        (sd) => sd.serviceProductId + "\n"
      );
      business_pt = businessService;
      next();
    } catch (error) {
      business_pt = [error.response.status, error.response.statusText];
      next();
    }
  };
}

module.exports = {
  getLRPortugal,
  getDesignPortugal,
  getPaxPortugal,
  getBusinessPortugal,
  getKitchenPortugal,
};
