const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = ["LIVINGROOM"];
const pinCode = "1101 BL";
const language = "nl-nl";

function getLRNetherland() {
  return async function (req, res, next) {
    try {
      const lr = await data_services.getServiceData(
        services[0],
        pinCode,
        language
      );

      const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
      lr_nl = lrServices;
      next();
    } catch (error) {
      lr_nl = [error.response.status, error.response.statusText];
      next();
    }
  };
}

module.exports = { getLRNetherland };
