const axios = require("axios");

Date.prototype.GetFirstDayOfWeek = function () {
  return new Date(
    this.setDate(this.getDate() - this.getDay() + (this.getDay() == 0 ? -6 : 1))
  );
};
let start_date = new Date().GetFirstDayOfWeek().toISOString().split("T")[0];

async function getCustomerBooking(
  service_type,
  pinCode,
  actual_service,
  language
) {
  try {
    let flag = false;
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${service_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );

    booking.status == 200 ? (flag = true) : (flag = false);
    flag ? (custBook = "circle") : (custBook = "circle-red");
    return custBook;
  } catch (error) {
    custBook = "circle-red";
    return custBook;
  }
}
module.exports = { getCustomerBooking };
