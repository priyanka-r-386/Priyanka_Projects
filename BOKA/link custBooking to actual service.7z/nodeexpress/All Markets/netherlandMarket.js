const express = require("express");
const data_services = require("../nodejs");

const services = ["LIVINGROOM"];
const pinCode = "1101 BL";
const language = "nl-nl";

const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getLRNetherland(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId);
    lr_nl = lrServices;

    const nlData = lr.data.map((sd) => [sd.locationType, sd.serviceProductId]);
    let customerBookings = [];

    for (let i in nlData) {
      locationType = getLocation.getLocation(nlData[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          nlData[i][1],
          language
        )
      );
    }

    customerLocationsNL = customerBookings.map((loc) => loc);

    next();
  } catch (error) {
    lr_nl = [error.response.status, error.response.statusText];
    customerLocationsNL = ["circle-red", "circle-red"];
    next();
  }
}

module.exports = { getLRNetherland };
