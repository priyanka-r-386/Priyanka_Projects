const india = document.getElementById("india");
const norway = document.querySelector("#Norway");
const denmark = document.querySelector("#denmark");
const portugal = document.querySelector("#portugal");
const poland = document.getElementById("poland");
const netherland = document.querySelector("#netherland");
const UK = document.querySelector("#UK");
const serbia = document.querySelector("#serbia");
const finland = document.querySelector("#finland");

const services_group = document.querySelector(".service_group");

async function getBookingData(url, coWorkerClass) {
  const response = await fetch(url);
  const bookingData = response.json();

  bookingData.then((res) => {
    let flag = false;
    res.length > 1 ? (flag = true) : (flag = false);
    flag ? (coworkerbooking = "circle") : (coworkerbooking = "circle-red");
    const element = document.querySelector(coWorkerClass);
    element.classList.add(coworkerbooking);
  });
}

function removeClasslist(classList) {
  document.querySelector(classList).classList.contains("circle")
    ? document.querySelector(classList).classList.remove("circle")
    : document.querySelector(classList).classList.remove("circle-red");
}
//Add Indian Market
india.addEventListener("input", function (e) {
  if (india.checked === true) {
    getBookingData("./JsonData/IN/IN_DECORATION.json", ".coworker-booking1-in");
    getBookingData(
      "./JsonData/IN/IN_HOME_FURNISHING_BASIC.json",
      ".coworker-booking2-in"
    );
    getBookingData(
      "./JsonData/IN/IN_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking3-in"
    );
    getBookingData(
      "./JsonData/IN/IN_ID_BUSINESS_REMOTE.json",
      ".coworker-booking4-in"
    );
    getBookingData(
      "./JsonData/IN/IN_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking5-in"
    );
    getBookingData(
      "./JsonData/IN/IN_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking6-in"
    );
    if (services_group.hasChildNodes(".services_india")) {
      services_group.appendChild(document.querySelector(".services_india"));
      document.querySelector(".services_india").style.display = "initial";
    }
  }
  //Remove market when unchecked
  if (india.checked === false) {
    removeClasslist(".coworker-booking1-in");
    removeClasslist(".coworker-booking2-in");
    removeClasslist(".coworker-booking3-in");
    removeClasslist(".coworker-booking4-in");
    removeClasslist(".coworker-booking5-in");
    removeClasslist(".coworker-booking6-in");
    document.querySelector(".services_india").style.display = "none";
  }
});

//Add services to Norway Market
norway.addEventListener("input", function (e) {
  if (norway.checked === true) {
    getBookingData(
      "./JsonData/NO/NO_HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-no"
    );
    getBookingData(
      "./JsonData/NO/NO_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking3-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking4-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_WARDROBE.json",
      ".coworker-booking5-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking6-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking7-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_BATHROOM_STORE.json",
      ".coworker-booking8-no"
    );
    getBookingData(
      "./JsonData/NO/NO_BUSINESS_PLANNING.json",
      ".coworker-booking9-no"
    );
    getBookingData(
      "./JsonData/NO/NO_PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking10-no"
    );
    services_group.appendChild(document.querySelector(".services_norway"));
    document.querySelector(".services_norway").style.display = "initial";
  }
  //Remove market when unchecked
  if (norway.checked === false) {
    removeClasslist(".coworker-booking1-no");
    removeClasslist(".coworker-booking2-no");
    removeClasslist(".coworker-booking3-no");
    removeClasslist(".coworker-booking4-no");
    removeClasslist(".coworker-booking5-no");
    removeClasslist(".coworker-booking6-no");
    removeClasslist(".coworker-booking7-no");
    removeClasslist(".coworker-booking8-no");
    removeClasslist(".coworker-booking9-no");
    removeClasslist(".coworker-booking10-no");

    document.querySelector(".services_norway").style.display = "none";
  }
});

// Adding Denmark Market
denmark.addEventListener("input", function (e) {
  if (denmark.checked === true) {
    getBookingData(
      "./JsonData/DK/DK_HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-dk"
    );
    getBookingData(
      "./JsonData/DK/DK_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-dk"
    );
    getBookingData(
      "./JsonData/DK/DK_BUSINESS_PLANNING.json",
      ".coworker-booking3-dk"
    );
    getBookingData(
      "./JsonData/DK/DK_PLANNING_BATHROOM_REMOTE.json",
      ".coworker-booking4-dk"
    );

    services_group.appendChild(document.querySelector(".services_denmark"));
    document.querySelector(".services_denmark").style.display = "initial";
  }

  //Remove market when unchecked
  if (denmark.checked === false) {
    removeClasslist(".coworker-booking1-dk");
    removeClasslist(".coworker-booking2-dk");
    removeClasslist(".coworker-booking3-dk");
    removeClasslist(".coworker-booking4-dk");
    document.querySelector(".services_denmark").style.display = "none";
  }
});

//Add portugal Market
portugal.addEventListener("input", function (e) {
  if (portugal.checked === true) {
    getBookingData(
      "./JsonData/PT/PT_HOME_FURNISHING_BASIC_CUSTOMER.json",
      ".coworker-booking1-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking3-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_SEASONAL_CUSTOMER.json",
      ".coworker-booking4-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_LIVING_ROOM.json",
      ".coworker-booking5-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking6-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_WARDROBE.json",
      ".coworker-booking7-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_WARDROBE_CUSTOMER.json",
      ".coworker-booking8-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking9-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_BUSINESS_PLANNING.json",
      ".coworker-booking10-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking11-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking12-pt"
    );
    getBookingData(
      "./JsonData/PT/PT_PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking13-pt"
    );

    services_group.appendChild(document.querySelector(".portugal_services "));
    document.querySelector(".portugal_services ").style.display = "initial";
  }
  //Remove market when unchecked
  if (portugal.checked === false) {
    removeClasslist(".coworker-booking1-pt");
    removeClasslist(".coworker-booking2-pt");
    removeClasslist(".coworker-booking3-pt");
    removeClasslist(".coworker-booking4-pt");
    removeClasslist(".coworker-booking5-pt");
    removeClasslist(".coworker-booking6-pt");
    removeClasslist(".coworker-booking7-pt");
    removeClasslist(".coworker-booking8-pt");
    removeClasslist(".coworker-booking9-pt");
    removeClasslist(".coworker-booking10-pt");
    removeClasslist(".coworker-booking11-pt");
    removeClasslist(".coworker-booking12-pt");
    removeClasslist(".coworker-booking13-pt");
    document.querySelector(".portugal_services ").style.display = "none";
  }
});

//Netherland Market

netherland.addEventListener("input", function (e) {
  if (netherland.checked === true) {
    getBookingData(
      "./JsonData/NL/NL_PLANNING_LIVING_ROOM.json",
      ".coworker-booking1-nl"
    );
    getBookingData(
      "./JsonData/NL/NL_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking2-nl"
    );
    services_group.appendChild(document.querySelector(".services_netherland"));
    document.querySelector(".services_netherland").style.display = "initial";
  }
  //Remove market when unchecked
  if (netherland.checked === false) {
    removeClasslist(".coworker-booking1-nl");
    removeClasslist(".coworker-booking2-nl");
    document.querySelector(".services_netherland").style.display = "none";
  }
});

// Poland Market
poland.addEventListener("input", function (e) {
  if (poland.checked === true) {
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_BASIC_CUSTOMER.json",
      ".coworker-booking2-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking3-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking4-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_COMPLETE_CUSTOMER.json",
      ".coworker-booking5-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking6-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_LIVING_ROOM.json",
      ".coworker-booking7-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking8-pl"
    );

    getBookingData(
      "./JsonData/PL/PL_PLANNING_WARDROBE.json",
      ".coworker-booking9-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking10-pl"
    );

    getBookingData(
      "./JsonData/PL/PL_DECORATION_BUSINESS.json",
      ".coworker-booking11-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_BUSINESS_PLANNING.json",
      ".coworker-booking12-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking13-pl"
    );
    getBookingData(
      "./JsonData/PL/PL_PLANNING_HOME_SMART_REMOTE.json",
      ".coworker-booking14-pl"
    );

    services_group.appendChild(document.querySelector(".services_poland"));
    document.querySelector(".services_poland").style.display = "initial";
  }
  //Remove market when unchecked
  if (poland.checked === false) {
    removeClasslist(".coworker-booking1-pl");
    removeClasslist(".coworker-booking2-pl");
    removeClasslist(".coworker-booking3-pl");
    removeClasslist(".coworker-booking4-pl");
    removeClasslist(".coworker-booking5-pl");
    removeClasslist(".coworker-booking6-pl");
    removeClasslist(".coworker-booking7-pl");
    removeClasslist(".coworker-booking8-pl");
    removeClasslist(".coworker-booking9-pl");
    removeClasslist(".coworker-booking10-pl");
    removeClasslist(".coworker-booking11-pl");
    removeClasslist(".coworker-booking12-pl");
    removeClasslist(".coworker-booking13-pl");
    removeClasslist(".coworker-booking14-pl");
    document.querySelector(".services_poland").style.display = "none";
  }
});

//UK Market
UK.addEventListener("input", function (e) {
  if (UK.checked === true) {
    getBookingData(
      "./JsonData/UK/UK_HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking1-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_LIVING_ROOM.json",
      ".coworker-booking2-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_LIVING_ROOM_REMOTE.json",
      ".coworker-booking3-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_WARDROBE.json",
      ".coworker-booking4-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking5-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking6-uk"
    );

    getBookingData(
      "./JsonData/UK/UK_VERIFY_PLANNING_AND_DRAWING.json",
      ".coworker-booking7-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_KITCHEN_STORE.json",
      ".coworker-booking8-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking9-uk"
    );
    getBookingData(
      "./JsonData/UK/UK_INTERIOR_DESIGN_BUSINESS_CONSULTATION.json",
      ".coworker-booking10-uk"
    );
    services_group.appendChild(document.querySelector(".services_uk"));
    document.querySelector(".services_uk").style.display = "initial";
  }

  //Remove market when unchecked
  if (UK.checked === false) {
    removeClasslist(".coworker-booking1-uk");
    removeClasslist(".coworker-booking2-uk");
    removeClasslist(".coworker-booking3-uk");
    removeClasslist(".coworker-booking4-uk");
    removeClasslist(".coworker-booking5-uk");
    removeClasslist(".coworker-booking6-uk");
    removeClasslist(".coworker-booking7-uk");
    removeClasslist(".coworker-booking8-uk");
    removeClasslist(".coworker-booking9-uk");
    removeClasslist(".coworker-booking10-uk");
    document.querySelector(".services_uk").style.display = "none";
  }
});

// Serbia Market
serbia.addEventListener("input", function (e) {
  if (serbia.checked === true) {
    getBookingData(
      "./JsonData/RS/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking1-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_CUSTOMER.json",
      ".coworker-booking2-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_CUSTOMER_ADDITIONAL.json",
      ".coworker-booking3-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking4-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking5-rs"
    );
    getBookingData(
      "./JsonData/RS/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking6-rs"
    );
    getBookingData(
      "./JsonData/RS/INTERIOR_DESIGN_BUSINESS.json",
      ".coworker-booking7-rs"
    );

    services_group.appendChild(document.querySelector(".services_serbia"));
    document.querySelector(".services_serbia").style.display = "initial";
  }
  //Remove market when unchecked
  if (serbia.checked === false) {
    removeClasslist(".coworker-booking1-rs");
    removeClasslist(".coworker-booking2-rs");
    removeClasslist(".coworker-booking3-rs");
    removeClasslist(".coworker-booking4-rs");
    removeClasslist(".coworker-booking5-rs");
    removeClasslist(".coworker-booking6-rs");
    removeClasslist(".coworker-booking7-rs");
    document.querySelector(".services_serbia").style.display = "none";
  }
});

finland.addEventListener("input", function (e) {
  if (finland.checked === true) {
    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_BASIC.json",
      ".coworker-booking1-fi"
    );
    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_BASIC_REMOTE.json",
      ".coworker-booking2-fi"
    );
    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_COMPLETE.json",
      ".coworker-booking3-fi"
    );
    getBookingData(
      "./JsonData/FI/HOME_FURNISHING_COMPLETE_REMOTE.json",
      ".coworker-booking4-fi"
    );

    getBookingData(
      "./JsonData/FI/PLANNING_KITCHEN_CUSTOMER.json",
      ".coworker-booking5-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_KITCHEN_REMOTE.json",
      ".coworker-booking6-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_KITCHEN_MEETING_POINT.json",
      ".coworker-booking7-fi"
    );

    getBookingData(
      "./JsonData/FI/PLANNING_WARDROBE.json",
      ".coworker-booking8-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_WARDROBE_REMOTE.json",
      ".coworker-booking9-fi"
    );
    getBookingData(
      "./JsonData/FI/PLANNING_BUSINESS_REMOTE.json",
      ".coworker-booking10-fi"
    );
    getBookingData(
      "./JsonData/FI/RENT_A_TRAILER.json",
      ".coworker-booking11-fi"
    );

    services_group.appendChild(document.querySelector(".services_finland"));
    removeClasslist(".coworker-booking1-fi");
    removeClasslist(".coworker-booking2-fi");
    removeClasslist(".coworker-booking3-fi");
    removeClasslist(".coworker-booking4-fi");
    removeClasslist(".coworker-booking5-fi");
    removeClasslist(".coworker-booking6-fi");
    removeClasslist(".coworker-booking7-fi");
    removeClasslist(".coworker-booking8-fi");
    removeClasslist(".coworker-booking9-fi");
    removeClasslist(".coworker-booking10-fi");
    removeClasslist(".coworker-booking11-fi");
    document.querySelector(".services_finland").style.display = "initial";
  }
  //Remove market when unchecked
  if (finland.checked === false) {
    document.querySelector(".services_finland").style.display = "none";
  }
});
