const axios = require("axios");
const pinCode = "03-286";
const language = "pl-pl";

Date.prototype.GetFirstDayOfWeek = function () {
  return new Date(
    this.setDate(this.getDate() - this.getDay() + (this.getDay() == 0 ? -6 : 1))
  );
};
let start_date = new Date().GetFirstDayOfWeek().toISOString().split("T")[0];

function getBookingData1(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });

      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking_pl = "circle")
      : (customer_booking_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking_pl = "circle-red";
      next();
    }
  };
}

function getBookingData2(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });

      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking2_pl = "circle")
      : (customer_booking2_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking2_pl = "circle-red";
      next();
    }
  };
}

function getBookingData3(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking3_pl = "circle")
      : (customer_booking3_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking3_pl = "circle-red";
      next();
    }
  };
}

function getBookingData4(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking4_pl = "circle")
      : (customer_booking4_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking4_pl = "circle-red";
      next();
    }
  };
}

function getBookingData5(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking5_pl = "circle")
      : (customer_booking5_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking5_pl = "circle-red";
      next();
    }
  };
}

function getBookingData6(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking6_pl = "circle")
      : (customer_booking6_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking6_pl = "circle-red";
      next();
    }
  };
}

function getBookingData7(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking7_pl = "circle")
      : (customer_booking7_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking7_pl = "circle-red";
      next();
    }
  };
}

function getBookingData8(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking8_pl = "circle")
      : (customer_booking8_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking8_pl = "circle-red";
      next();
    }
  };
}

function getBookingData9(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking9_pl = "circle")
      : (customer_booking9_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking9_pl = "circle-red";
      next();
    }
  };
}

function getBookingData10(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking10_pl = "circle")
      : (customer_booking10_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking10_pl = "circle-red";
      next();
    }
  };
}

function getBookingData11(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking11_pl = "circle")
      : (customer_booking11_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking11_pl = "circle-red";
      next();
    }
  };
}

function getBookingData12(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking12_pl = "circle")
      : (customer_booking12_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking12_pl = "circle-red";
      next();
    }
  };
}

function getBookingData13(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking13_pl = "circle")
      : (customer_booking13_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking13_pl = "circle-red";
      next();
    }
  };
}

function getBookingData14(services_type, actual_service) {
  return async function (req, res, next) {
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );
    const locations = booking.data.map((res) => res.externalId);

    let flag = false;
    for (let i in locations) {
      await axios
        .get(
          `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}/${i}?from=${start_date}`,
          {
            headers: {
              accept: "application/json",
              "accept-language": `${language}`, //the token is a variable which holds the token
            },
          }
        )
        .then((res) => {
          if (res.status === 200) flag = true;
          return flag;
        })
        .catch((err) => {
          flag = false;
        });
      if ((flag = true)) {
        break;
      } else continue;
    }

    flag
      ? (customer_booking14_pl = "circle")
      : (customer_booking14_pl = "circle-red");

    next();
    if (booking.status !== 200) {
      customer_booking14_pl = "circle-red";
      next();
    }
  };
}

module.exports = {
  getBookingData1,
  getBookingData2,
  getBookingData3,
  getBookingData4,
  getBookingData5,
  getBookingData6,
  getBookingData7,
  getBookingData8,
  getBookingData9,
  getBookingData10,
  getBookingData11,
  getBookingData12,
  getBookingData13,
  getBookingData14,
};
