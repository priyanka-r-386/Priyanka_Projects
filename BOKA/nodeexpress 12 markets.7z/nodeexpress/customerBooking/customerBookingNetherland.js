const axios = require("axios");
const pinCode = "1101 BL";
const language = "nl-nl";

Date.prototype.GetFirstDayOfWeek = function () {
  return new Date(
    this.setDate(this.getDate() - this.getDay() + (this.getDay() == 0 ? -6 : 1))
  );
};
let start_date = new Date().GetFirstDayOfWeek().toISOString().split("T")[0];

function getBookingData1(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status == 200) {
        customer_booking_nl = "circle";
      }

      next();
    } catch (error) {
      customer_booking_nl = "circle-red";
      next();
    }
  };
}

function getBookingData2(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status == 200) {
        customer_booking1_nl = "circle";
      }

      next();
    } catch (error) {
      customer_booking1_nl = "circle-red";
      next();
    }
  };
}
module.exports = {
  getBookingData1,
  getBookingData2,
};
