const express = require("express");
const chalk = require("chalk");
const path = require("path");
const morgan = require("morgan");
const app = express();

const compression = require("compression");
const indiaMarket = require("./All Markets/indianMarket");
const denmarkMarket = require("./All Markets/denmarkMarket");
const polandMarket = require("./All Markets/polandMarket");
const portugalMarket = require("./All Markets/portugalMarket");
const netherlandMarket = require("./All Markets/netherlandMarket");
const ukMarket = require("./All Markets/UKMarket");
const norwayMarket = require("./All Markets/norwayMarket");
const serbiaMarket = require("./All Markets/serbiaMarket");
const finlandMarket = require("./All Markets/finlandMarket");
const irelandMarket = require("./All Markets/irelandMarket");
const japanMarket = require("./All Markets/japanMarket");
const CHMarket = require("./All Markets/switzerlandMarket");
const SwedenMarket = require("./All Markets/swedenMarket");

const PORT = process.env.PORT || 4000;

app.use(express.static(path.join(__dirname, "/public/")));

app.use(morgan("tiny"));

app.set("views", "./src/views");
app.set("view engine", "ejs");

app.use(compression());

app.use(express.static("public"));

function errorHandler(err, req, res, next) {
  console.error(err.stack);
  res.status(500).send("Something broke!");
}

app.get("/index", (req, res) => {
  res.render("header");
});

const middlewares = [
  SwedenMarket.getBathroomSweden,
  SwedenMarket.getBedroomSweden,
  SwedenMarket.getLivingRoomSweden,
  SwedenMarket.getPaxSweden,
  SwedenMarket.getSofaSweden,
  SwedenMarket.getWorkspaceSweden,
  SwedenMarket.getDesignSweden,
  SwedenMarket.getSeasonalSweden,
  japanMarket.getBathroomJapan,
  japanMarket.getBedroomJapan,
  japanMarket.getBusinessDesignConsultationJapan,
  japanMarket.getBusinessInteriorDesignJapan,
  japanMarket.getDesignJapan,
  japanMarket.getKitchenJapan,
  japanMarket.getPaxJapan,
  japanMarket.getBusinessJapan,
  irelandMarket.getBedroomIreland,
  irelandMarket.getDesignIreland,
  irelandMarket.getLrIreland,
  portugalMarket.getBusinessPortugal,
  portugalMarket.getDesignPortugal,
  portugalMarket.getKitchenPortugal,
  portugalMarket.getLRPortugal,
  portugalMarket.getPaxPortugal,
  denmarkMarket.getDesignDenmark,
  denmarkMarket.getBusinessDenmark,
  denmarkMarket.getBathroomDenmark,
  serbiaMarket.getBedroomSerbia,
  serbiaMarket.getBusinessSerbia,
  serbiaMarket.getDesignSerbia,
  serbiaMarket.getKitchenSerbia,
  finlandMarket.getBathroomFinland,
  finlandMarket.getBedroomFinland,
  finlandMarket.getBusinessFinland,
  finlandMarket.getKitchenFinland,
  finlandMarket.getDesignFinland,
  finlandMarket.getLRFinland,
  finlandMarket.getTrailorFinland,
  polandMarket.getDesignPoland,
  polandMarket.getPaxPoland,
  polandMarket.getLRPoland,
  polandMarket.getBusinessPoland,
  polandMarket.getSmartHomePoland,
  netherlandMarket.getLRNetherland,
  ukMarket.getBedroomUK,
  ukMarket.getBusinessConsultationUK,
  ukMarket.getDesignUK,
  ukMarket.getKitchenUK,
  ukMarket.getLRUK,
  ukMarket.getBusinessUK,
  norwayMarket.getBathroomNorway,
  norwayMarket.getBusinessNorway,
  norwayMarket.getDesignNorway,
  norwayMarket.getKitchenNorway,
  norwayMarket.getPaxNorway,
  indiaMarket.getDesignIndia,
  indiaMarket.getLRIndia,
  indiaMarket.getPaxIndia,
  CHMarket.getDesignCH,
  CHMarket.getBusinessCH,
];

app.use(
  "/IE",
  irelandMarket.getBedroomIreland,
  irelandMarket.getDesignIreland,
  irelandMarket.getLrIreland,
  (req, res) => {
    res.render("ireland", {
      lr_ie,
      design_ie,
      bedroom_ie,
      custBookIEDesign,
      custBookIEBedroom,
      custBookIELr,
    });
  }
);
/*app.use(
  "/IE",
  irelandMarket.getBedroomIreland,
  irelandMarket.getDesignIreland,
  irelandMarket.getLrIreland,
  (req, res) => {
    res.render("ireland", {
      lr_ie,
      design_ie,
      bedroom_ie,
    });
  }
);*/

app.use(
  "/PT",
  portugalMarket.getBusinessPortugal,
  portugalMarket.getDesignPortugal,
  portugalMarket.getKitchenPortugal,
  portugalMarket.getLRPortugal,
  portugalMarket.getPaxPortugal,
  (req, res) => {
    res.render("portugal", {
      design_pt: design_pt,
      lr_pt: lr_pt,
      pax_pt: pax_pt,
      kitchen_pt: kitchen_pt,
      business_pt: business_pt,
      design1_bk_pt: custBookPtDesign[0],
      design2_bk_pt: custBookPtDesign[1],
      design3_bk_pt: custBookPtDesign[2],
      design4_bk_pt: custBookPtDesign[3],
      design5_bk_pt: custBookPtLr[0],
      design6_bk_pt: custBookPtLr[1],
      design7_bk_pt: custBookPtPax[0],
      design8_bk_pt: custBookPtPax[1],
      design9_bk_pt: custBookPtPax[2],
      design10_bk_pt: custBookPtBusiness[0],
      design11_bk_pt: custBookPtKitchen[0],
      design12_bk_pt: custBookPtKitchen[1],
      design13_bk_pt: custBookPtKitchen[2],
    });
  }
);

app.use(
  "/DK",
  denmarkMarket.getDesignDenmark,
  denmarkMarket.getBusinessDenmark,
  denmarkMarket.getBathroomDenmark,
  (req, res) => {
    res.render("denmark", {
      design_dk: design_dk,
      business_dk: business_dk,
      bathroom_dk: bathroom_dk,
      cust_book_dk1: custBookDKDesign[0],
      cust_book_dk2: custBookDKDesign[1],
      cust_book_dk3: custBookDKBusiness[0],
      cust_book_dk4: custBookDKBathroom[0],
    });
  }
);

app.use(
  "/PL",
  polandMarket.getDesignPoland,
  polandMarket.getPaxPoland,
  polandMarket.getLRPoland,
  polandMarket.getBusinessPoland,
  polandMarket.getSmartHomePoland,
  (req, res) => {
    res.render("poland", {
      design_pl: design_pl,
      pax_pl: pax_pl,
      lr_pl: lr_pl,
      business_pl: business_pl,
      sh_pl: sh_pl,
      cust_book_pl1: custBookPlDesign[0],
      cust_book_pl6: custBookPlDesign[5],
      cust_book_pl2: custBookPlDesign[1],
      cust_book_pl3: custBookPlDesign[2],
      cust_book_pl4: custBookPlDesign[3],
      cust_book_pl5: custBookPlDesign[4],
      cust_book_pl7: custBookPlLr[0],
      cust_book_pl8: custBookPlLr[1],
      cust_book_pl9: custBookPlPax[0],
      cust_book_pl10: custBookPlPax[1],
      cust_book_pl11: custBookPlbusiness[0],
      cust_book_pl12: custBookPlbusiness[1],
      cust_book_pl13: custBookPlbusiness[2],
      cust_book_pl14: custBookPlSmartHome,
      custBookPlbusiness,
    });
  }
);

app.use("/NL", netherlandMarket.getLRNetherland, (req, res) => {
  res.render("netherlands", {
    lr_nl: lr_nl,
    cust_book_nl1: customerLocationsNL[0],
    cust_book_nl2: customerLocationsNL[1],
  });
});

app.use(
  "/GB",
  ukMarket.getBedroomUK,
  ukMarket.getBusinessConsultationUK,
  ukMarket.getDesignUK,
  ukMarket.getKitchenUK,
  ukMarket.getLRUK,
  ukMarket.getBusinessUK,
  (req, res) => {
    res.render("UK", {
      design_uk: design_uk,
      lr_uk: lr_uk,
      business_uk: business_uk,
      bedroom_uk: bedroom_uk,
      kitchen_uk: kitchen_uk,
      business_consultation_uk: business_consultation_uk,
      cust_book_uk1: custBookGBDesign[0],
      cust_book_uk6: custBookGBBusiness,
      cust_book_uk2: custBookGBLr[0],
      cust_book_uk3: custBookGBLr[1],
      cust_book_uk4: custBookGBBedroom[0],
      cust_book_uk5: custBookGBBedroom[1],
      cust_book_uk7: custBookGBKitchen[0],
      cust_book_uk8: custBookGBKitchen[1],
      cust_book_uk9: custBookGBKitchen[2],
      cust_book_uk10: custBookGBBusinessConsultation,
    });
  }
);

app.use(
  "/NO",
  norwayMarket.getBathroomNorway,
  norwayMarket.getBusinessNorway,
  norwayMarket.getDesignNorway,
  norwayMarket.getKitchenNorway,
  norwayMarket.getPaxNorway,
  (req, res) => {
    res.render("norway", {
      design_no: design_no,
      pax_no: pax_no,
      kitchen_no: kitchen_no,
      bathroom_no: bathroom_no,
      business_no: business_no,
      cust_book_no1: custBookNODesign[0],
      cust_book_no6: custBookNOPax[1],
      cust_book_no2: custBookNODesign[1],
      cust_book_no3: custBookNOKitchen[0],
      cust_book_no4: custBookNOKitchen[1],
      cust_book_no5: custBookNOPax[0],
      cust_book_no7: custBookNOBathroom[0],
      cust_book_no8: custBookNOBathroom[1],
      cust_book_no9: custBookNOBusiness[0],
      cust_book_no10: custBookNOBusiness[1],
    });
  }
);

app.use(
  "/IN",
  indiaMarket.getDesignIndia,
  indiaMarket.getLRIndia,
  indiaMarket.getPaxIndia,

  (req, res) => {
    res.render("india", {
      design_in: actual_service,
      lr_in: lr_service,
      pax_in: pax_service,
      cust_book_in1: custBookINDesign[0],
      cust_book_in2: custBookINDesign[1],
      cust_book_in3: custBookINDesign[2],
      cust_book_in4: custBookINDesign[3],
      cust_book_in5: custBookINLr[0],
      cust_book_in6: custBookINPax[0],
    });
  }
);

app.use(
  "/RS",
  serbiaMarket.getBedroomSerbia,
  serbiaMarket.getBusinessSerbia,
  serbiaMarket.getDesignSerbia,
  serbiaMarket.getKitchenSerbia,

  (req, res) => {
    res.render("serbia", {
      bedroom_sr: bedroom_sr,
      design_sr: design_sr,
      kitchen_sr: kitchen_sr,
      business_sr: business_sr,
      custBookRSDesign,
      custBookRSBedroom,
      custBookRSKitchen,
      custBookRSBusiness,
    });
  }
);

app.use(
  "/FI",
  finlandMarket.getBathroomFinland,
  finlandMarket.getBedroomFinland,
  finlandMarket.getBusinessFinland,
  finlandMarket.getKitchenFinland,
  finlandMarket.getDesignFinland,
  finlandMarket.getLRFinland,
  finlandMarket.getTrailorFinland,
  (req, res) => {
    res.render("finland", {
      bathroom_fl: bathroom_fl,
      business_fl: business_fl,
      bedroom_fl: bedroom_fl,
      design_fl: design_fl,
      kitchen_fl: kitchen_fl,
      business_fl: business_fl,
      trailor_fl: trailor_fl,
      custBookFIBathroom,
      custBookFIDesign,
      custBookFIKitchen,
      // custBookFILr,
      custBookFITrailor,
      custBookFIBedroom,
      custBookFIBusiness,
    });
  }
);

app.use(
  "/JP",
  japanMarket.getBathroomJapan,
  japanMarket.getBedroomJapan,
  japanMarket.getBusinessDesignConsultationJapan,
  japanMarket.getBusinessInteriorDesignJapan,
  japanMarket.getDesignJapan,
  japanMarket.getKitchenJapan,
  japanMarket.getPaxJapan,
  japanMarket.getBusinessJapan,
  (req, res) => {
    res.render("japan", {
      bathroom_jp,
      business_jp,
      bedroom_jp,
      design_jp,
      kitchen_jp,
      pax_jp,
      businessDC_jp,
      businessID_jp,
      custBookJpDesign,
      custBookJpPax,
      custBookJpKitchen,
      custBookJpBusiness,
      custBookJpBusinessDC,
      custBookJpBusinessID,
      custBookJpBathroom,
      custBookJpBedroom,
    });
  }
);

app.use("/CH", CHMarket.getDesignCH, CHMarket.getBusinessCH, (req, res) => {
  res.render("switzerland", {
    design_ch,
    business_ch,
    custBookCHDesign,
    custBookCHbusiness,
  });
});

app.use(
  "/SE",
  SwedenMarket.getBathroomSweden,
  SwedenMarket.getBedroomSweden,
  SwedenMarket.getLivingRoomSweden,
  SwedenMarket.getPaxSweden,
  SwedenMarket.getSofaSweden,
  SwedenMarket.getWorkspaceSweden,
  SwedenMarket.getDesignSweden,
  SwedenMarket.getSeasonalSweden,
  (req, res) => {
    res.render("sweden", {
      design_se,
      lr_se,
      pax_se,
      bedroom_se,
      bathroom_se,
      sofa_se,
      seasonal_se,
      Workspace_se,
      custBookSEWorkspace,
      custBookSESofa,
      custBookSESeasonal,
      custBookSEPax,
      custBookSEBathroom,
      custBookSEBedroom,
      custBookSELr,
      custBookSEDesign,
    });
  }
);

app.get(
  "/",
  [...middlewares],

  (req, res) => {
    res.render("index", {
      design_pt: design_pt,
      lr_pt: lr_pt,
      pax_pt: pax_pt,
      kitchen_pt: kitchen_pt,
      business_pt: business_pt,
      design1_bk_pt: custBookPtDesign[0],
      design2_bk_pt: custBookPtDesign[1],
      design3_bk_pt: custBookPtDesign[2],
      design4_bk_pt: custBookPtDesign[3],
      design5_bk_pt: custBookPtLr[0],
      design6_bk_pt: custBookPtLr[1],
      design7_bk_pt: custBookPtPax[0],
      design8_bk_pt: custBookPtPax[1],
      design9_bk_pt: custBookPtPax[2],
      design10_bk_pt: custBookPtBusiness[0],
      design11_bk_pt: custBookPtKitchen[0],
      design12_bk_pt: custBookPtKitchen[1],
      design13_bk_pt: custBookPtKitchen[2],
      bedroom_sr: bedroom_sr,
      design_sr: design_sr,
      kitchen_sr: kitchen_sr,
      business_sr: business_sr,
      custBookRSDesign,
      custBookRSBedroom,
      custBookRSKitchen,
      custBookRSBusiness,
      bathroom_fl: bathroom_fl,
      business_fl: business_fl,
      bedroom_fl: bedroom_fl,
      design_fl: design_fl,
      kitchen_fl: kitchen_fl,
      business_fl: business_fl,
      trailor_fl: trailor_fl,
      custBookFIBathroom,
      custBookFIDesign,
      custBookFIKitchen,
      // custBookFILr,
      custBookFITrailor,
      custBookFIBedroom,
      custBookFIBusiness,
      design_dk: design_dk,
      business_dk: business_dk,
      bathroom_dk: bathroom_dk,
      cust_book_dk1: custBookDKDesign[0],
      cust_book_dk2: custBookDKDesign[1],
      cust_book_dk3: custBookDKBusiness[0],
      cust_book_dk4: custBookDKBathroom[0],
      design_pl: design_pl,
      pax_pl: pax_pl,
      lr_pl: lr_pl,
      business_pl: business_pl,
      sh_pl: sh_pl,
      cust_book_pl1: custBookPlDesign[0],
      cust_book_pl6: custBookPlDesign[5],
      cust_book_pl2: custBookPlDesign[1],
      cust_book_pl3: custBookPlDesign[2],
      cust_book_pl4: custBookPlDesign[3],
      cust_book_pl5: custBookPlDesign[4],
      cust_book_pl7: custBookPlLr[0],
      cust_book_pl8: custBookPlLr[1],
      cust_book_pl9: custBookPlPax[0],
      cust_book_pl10: custBookPlPax[1],
      cust_book_pl11: custBookPlbusiness[0],
      cust_book_pl12: custBookPlbusiness[1],
      cust_book_pl13: custBookPlbusiness[2],
      cust_book_pl14: custBookPlSmartHome,
      custBookPlbusiness,
      lr_nl: lr_nl,
      cust_book_nl1: customerLocationsNL[0],
      cust_book_nl2: customerLocationsNL[1],
      design_uk: design_uk,
      lr_uk: lr_uk,
      business_uk: business_uk,
      bedroom_uk: bedroom_uk,
      kitchen_uk: kitchen_uk,
      business_consultation_uk: business_consultation_uk,
      cust_book_uk1: custBookGBDesign[0],
      cust_book_uk6: custBookGBBusiness,
      cust_book_uk2: custBookGBLr[0],
      cust_book_uk3: custBookGBLr[1],
      cust_book_uk4: custBookGBBedroom[0],
      cust_book_uk5: custBookGBBedroom[1],
      cust_book_uk7: custBookGBKitchen[0],
      cust_book_uk8: custBookGBKitchen[1],
      cust_book_uk9: custBookGBKitchen[2],
      cust_book_uk10: custBookGBBusinessConsultation,
      design_no: design_no,
      pax_no: pax_no,
      kitchen_no: kitchen_no,
      bathroom_no: bathroom_no,
      business_no: business_no,
      cust_book_no1: custBookNODesign[0],
      cust_book_no6: custBookNOPax[1],
      cust_book_no2: custBookNODesign[1],
      cust_book_no3: custBookNOKitchen[0],
      cust_book_no4: custBookNOKitchen[1],
      cust_book_no5: custBookNOPax[0],
      cust_book_no7: custBookNOBathroom[0],
      cust_book_no8: custBookNOBathroom[1],
      cust_book_no9: custBookNOBusiness[0],
      cust_book_no10: custBookNOBusiness[1],
      design_in: actual_service,
      lr_in: lr_service,
      pax_in: pax_service,
      cust_book_in1: custBookINDesign[0],
      cust_book_in2: custBookINDesign[1],
      cust_book_in3: custBookINDesign[2],
      cust_book_in4: custBookINDesign[3],
      cust_book_in5: custBookINLr[0],
      cust_book_in6: custBookINPax[0],
      lr_ie,
      design_ie,
      bedroom_ie,
      custBookIEDesign,
      custBookIEBedroom,
      custBookIELr,
      bathroom_jp,
      business_jp,
      bedroom_jp,
      design_jp,
      kitchen_jp,
      pax_jp,
      businessDC_jp,
      businessID_jp,
      custBookJpDesign,
      custBookJpPax,
      custBookJpKitchen,
      custBookJpBusiness,
      custBookJpBusinessDC,
      custBookJpBusinessID,
      custBookJpBathroom,
      custBookJpBedroom,
      design_se,
      lr_se,
      pax_se,
      bedroom_se,
      bathroom_se,
      sofa_se,
      seasonal_se,
      Workspace_se,
      custBookSEWorkspace,
      custBookSESofa,
      custBookSESeasonal,
      custBookSEPax,
      custBookSEBathroom,
      custBookSEBedroom,
      custBookSELr,
      custBookSEDesign,
      design_ch,
      business_ch,
      custBookCHDesign,
      custBookCHbusiness,
    });
  }
);

app.use;
//app.use(errorHandler);
app.listen(PORT, () => {
  console.log(`listening to port ${chalk.green(PORT)}`);
});
