const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = [
  "DESIGN",
  "BEDROOM",
  "LIVINGROOM",
  "KITCHEN",
  "BUSINESS",
  "TRAILER",
  "BATHROOM",
];
const pinCode = "00100";
const language = "fi-fi";
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesignFinland(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_fl = designServices;
    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookFIDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_fl = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBedroomFinland(req, res, next) {
  try {
    const bedroom = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const bedroomServices = bedroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bedroom_fl = bedroomServices;
    const locationService = bedroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookFIBedroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bedroom_fl = [error.response.status, error.response.statusText];
    next();
  }
}

async function getLRFinland(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_fl = lrServices;
    const locationService = lr.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookFILr = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    lr_fl = [error.response.status, error.response.statusText];
    next();
  }
}

async function getKitchenFinland(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_fl = kitchenService;
    const locationService = kitchen.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookFIKitchen = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    kitchen_fl = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessFinland(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[4],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_fl = businessService;
    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookFIBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_fl = [error.response.status, error.response.statusText];
    next();
  }
}

async function getTrailorFinland(req, res, next) {
  try {
    const trailor = await data_services.getServiceData(
      services[5],
      pinCode,
      language
    );

    const trailorService = trailor.data.map((sd) => sd.serviceProductId + "\n");
    trailor_fl = trailorService;
    const locationService = trailor.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookFITrailor = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    trailor_fl = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBathroomFinland(req, res, next) {
  try {
    const bathroom = await data_services.getServiceData(
      services[6],
      pinCode,
      language
    );

    const bathroomServices = bathroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bathroom_fl = bathroomServices;
    const locationService = bathroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookFIBathroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bathroom_fl = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getBathroomFinland,
  getBedroomFinland,
  getBusinessFinland,
  getDesignFinland,
  getKitchenFinland,
  getTrailorFinland,
  getLRFinland,
};
