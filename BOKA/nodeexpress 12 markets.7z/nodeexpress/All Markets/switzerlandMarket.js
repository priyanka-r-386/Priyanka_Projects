const express = require("express");
const data_services = require("../nodejs");
const app = express();
const pinCode = "1170";
const language = "en-ch";
const services = ["DESIGN", "BUSINESS"];
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesignCH(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_ch = designServices;
    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookCHDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_ch = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessCH(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_ch = businessService;
    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookCHbusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_ch = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = { getDesignCH, getBusinessCH };
