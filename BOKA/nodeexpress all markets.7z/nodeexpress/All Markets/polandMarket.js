const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = ["DESIGN", "PAX", "LIVINGROOM", "BUSINESS", "SMARTHOME"];
const pinCode = "03-286";
const language = "pl-pl";
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesignPoland(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_pl = designServices;
    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookPlDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_pl = [error.response.status, error.response.statusText];
    next();
  }
}

async function getPaxPoland(req, res, next) {
  try {
    const pax = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const paxServices = pax.data.map((sd) => sd.serviceProductId + "\n");
    pax_pl = paxServices;
    const locationService = pax.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookPlPax = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    pax_pl = [error.response.status, error.response.statusText];
    next();
  }
}

async function getLRPoland(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_pl = lrServices;
    const locationService = lr.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);
    let customerBookings = [];
    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);
      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookPlLr = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    lr_pl = [error.response.status, error.response.statusText];
    next();
  }
}

async function getSmartHomePoland(req, res, next) {
  try {
    const smarthome = await data_services.getServiceData(
      services[4],
      pinCode,
      language
    );

    const smartHomeService = smarthome.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    sh_pl = smartHomeService;
    const locationService = smarthome.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);
    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookPlSmartHome = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    sh_pl = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessPoland(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_pl = businessService;
    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookPlbusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_pl = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getLRPoland,
  getDesignPoland,
  getPaxPoland,
  getBusinessPoland,
  getSmartHomePoland,
};
