const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = ["DESIGN", "PAX", "LIVINGROOM", "BUSINESS", "KITCHEN"];
const pinCode = "2330-060";
const language = "pt-pt";
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesignPortugal(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_pt = designServices;

    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookPtDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_pt = [error.response.status, error.response.statusText];
    next();
  }
}

async function getPaxPortugal(req, res, next) {
  try {
    const pax = await data_services.getServiceData("PAX", pinCode, language);

    const paxServices = pax.data.map((sd) => sd.serviceProductId + "\n");
    pax_pt = paxServices;

    const locationService = pax.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookPtPax = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    pax_pt = [error.response.status, error.response.statusText];
    next();
  }
}

async function getLRPortugal(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_pt = lrServices;

    const locationService = lr.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookPtLr = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    lr_pt = [error.response.status, error.response.statusText];
    next();
  }
}

async function getKitchenPortugal(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[4],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_pt = kitchenService;

    const locationService = kitchen.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookPtKitchen = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    kitchen_pt = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessPortugal(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_pt = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookPtBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_pt = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getLRPortugal,
  getDesignPortugal,
  getPaxPortugal,
  getBusinessPortugal,
  getKitchenPortugal,
};
