const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = [
  "DESIGN",
  "PAX",
  "BEDROOM",
  "BATHROOM",
  "BUSINESS",
  "KITCHEN",
  "BUSINESSINTERIORDESIGN",
  "BUSINESSDESIGNCONSULTATION",
];
const pinCode = "100-0101";
const language = "ja-jp";
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getDesignJapan(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_jp = designServices;

    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookJpDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_jp = [error.response.status, error.response.statusText];
    next();
  }
}

async function getPaxJapan(req, res, next) {
  try {
    const pax = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const paxServices = pax.data.map((sd) => sd.serviceProductId + "\n");
    pax_jp = paxServices;

    const locationService = pax.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookJpPax = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    pax_jp = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBedroomJapan(req, res, next) {
  try {
    const bedroom = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const bedroomServices = bedroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bedroom_jp = bedroomServices;

    const locationService = bedroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookJpBedroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bedroom_jp = [error.response.status, error.response.statusText];
    next();
  }
}

async function getKitchenJapan(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[5],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_jp = kitchenService;

    const locationService = kitchen.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookJpKitchen = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    kitchen_Jp = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessJapan(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[4],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_jp = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookJpBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_jp = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessInteriorDesignJapan(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[6],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    businessID_jp = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookJpBusinessID = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    businessID_jp = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessDesignConsultationJapan(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[7],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    businessDC_jp = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookJpBusinessDC = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    businessDC_jp = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBathroomJapan(req, res, next) {
  try {
    const bathroom = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const bathroomService = bathroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bathroom_jp = bathroomService;
    const locationService = bathroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookJpBathroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bathroom_jp = [error.response.status, error.response.statusText];
    next();
  }
}
module.exports = {
  getPaxJapan,
  getBathroomJapan,
  getKitchenJapan,
  getBedroomJapan,
  getBusinessDesignConsultationJapan,
  getBusinessInteriorDesignJapan,
  getBusinessJapan,
  getDesignJapan,
};
