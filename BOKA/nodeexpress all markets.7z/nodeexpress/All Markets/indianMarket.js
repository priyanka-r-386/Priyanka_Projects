const express = require("express");
const data_services = require("../nodejs");
const app = express();
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");
const services = ["DESIGN", "LIVINGROOM", "PAX"];
const pinCode = "500032";
const language = "en-in";

async function getDesignIndia(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    actual_service = designServices;
    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookINDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    actual_service = [error.response.status, error.response.statusText];
    next();
  }
}

async function getPaxIndia(req, res, next) {
  try {
    const pax = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const paxServices = pax.data.map((sd) => sd.serviceProductId + "\n");
    pax_service = paxServices;
    const locationService = pax.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookINPax = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    pax_service = [error.response.status, error.response.statusText];
    next();
  }
}

async function getLRIndia(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_service = lrServices;
    const locationService = lr.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookINLr = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    lr_service = [error.response.status, error.response.statusText];
    next();
  }
}
/*

async function getIndiaData(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      "DESIGN",
      "500032",
      "en-in"
    );

    const lr = await data_services.getServiceData(
      "LIVINGROOM",
      "500032",
      "en-in"
    );
    //if(design)
    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    actual_service = designServices;

    const pax = await data_services.getServiceData("PAX", "500032", "en-in");

    const paxServices = pax.data.map((sd) => sd.serviceProductId + "\n");
    pax_service = paxServices;

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_service = lrServices;

    next();
  } catch (error) {
    next(error);
  }
}
*/
module.exports = { getDesignIndia, getLRIndia, getPaxIndia };
