const express = require("express");
const data_services = require("../nodejs");
const app = express();
const pinCode = "10361";
const language = "hr-hr";
const services = ["KITCHEN", "BUSINESS", "BEDROOM", "BATHROOM"];
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getKitchen(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_hr = kitchenService;

    const locationService = kitchen.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookHRKitchen = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    kitchen_hr = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusiness(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_hr = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookHRBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_hr = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBedroom(req, res, next) {
  try {
    const bedroom = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const bedroomServices = bedroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bedroom_hr = bedroomServices;

    const locationService = bedroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookHRBedroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bedroom_hr = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBathroom(req, res, next) {
  try {
    const bathroom = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const bathroomService = bathroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bathroom_hr = bathroomService;
    const locationService = bathroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }

    custBookHRBathroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bathroom_hr = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getKitchen,
  getBusiness,
  getBathroom,
  getBedroom,
};
