const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = ["BUSINESS"];
const pinCode = "2609";
const language = "en-au";
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");

async function getBusiness(Australiareq, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_au = businessService;

    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookAUBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_au = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getBusiness,
};
