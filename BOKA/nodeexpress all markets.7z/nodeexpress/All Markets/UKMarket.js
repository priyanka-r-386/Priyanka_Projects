const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = [
  "DESIGN",
  "BEDROOM",
  "LIVINGROOM",
  "BUSINESS",
  "KITCHEN",
  "BUSINESSDESIGNCONSULTATION",
];
const customerBooking = require("../Shared/customerBooking");
const getLocation = require("../Shared/getLocation");
const pinCode = "PE2 9ET";
const language = "en-gb";

async function getDesignUK(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_uk = designServices;

    const locationService = design.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookGBDesign = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    design_uk = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBedroomUK(req, res, next) {
  try {
    const bedroom = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const bedroomServices = bedroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bedroom_uk = bedroomServices;
    const locationService = bedroom.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookGBBedroom = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    bedroom_uk = [error.response.status, error.response.statusText];
    next();
  }
}

async function getLRUK(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_uk = lrServices;
    const locationService = lr.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookGBLr = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    lr_uk = [error.response.status, error.response.statusText];
    next();
  }
}

async function getKitchenUK(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[4],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_uk = kitchenService;
    const locationService = kitchen.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookGBKitchen = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    kitchen_uk = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessUK(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_uk = businessService;
    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookGBBusiness = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_uk = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessConsultationUK(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[5],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_consultation_uk = businessService;
    const locationService = business.data.map((sd) => [
      sd.locationType,
      sd.serviceProductId,
    ]);

    let customerBookings = [];

    for (let i in locationService) {
      locationType = getLocation.getLocation(locationService[i][0]);

      customerBookings.push(
        await customerBooking.getCustomerBooking(
          locationType,
          pinCode,
          locationService[i][1],
          language
        )
      );
    }
    custBookGBBusinessConsultation = customerBookings.map((loc) => loc);
    next();
  } catch (error) {
    business_consultation_uk = [
      error.response.status,
      error.response.statusText,
    ];
    next();
  }
}

module.exports = {
  getLRUK,
  getDesignUK,
  getBedroomUK,
  getBusinessConsultationUK,
  getBusinessUK,
  getKitchenUK,
};
