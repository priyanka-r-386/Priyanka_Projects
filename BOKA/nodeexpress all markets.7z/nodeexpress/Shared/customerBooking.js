const axios = require("axios");

Date.prototype.GetFirstDayOfWeek = function () {
  return new Date(
    this.setDate(this.getDate() - this.getDay() + (this.getDay() == 0 ? -6 : 1))
  );
};
let start_date = new Date().GetFirstDayOfWeek().toISOString().split("T")[0];

async function getCustomerBooking(
  service_type,
  pinCode,
  actual_service,
  language
) {
  try {
    let flag = false;
    const booking = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/${service_type}/${pinCode}/${actual_service}?from=${start_date}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );

    /*
    if (service_type == "locations") {
      const locations = booking.data.map((res) => res.externalId);
      for (let i in locations) {
        await axios
          .get(
            `https://order-timewindow.ocp.ingka.ikea.com/services/${pinCode}/${actual_service}/${locations[i]}?from=${start_date}`,
            {
              headers: {
                accept: "application/json",
                "accept-language": `${language}`, //the token is a variable which holds the token
              },
            }
          )
          .then((res) => {
            res.status == 200 ? (flag = true) : (flag = false);
            return flag;
          })
          .catch((err) => {
            flag = false;
          });

        if ((flag = true)) {
          break;
        } else continue;
      }
    } else if (service_type == "services") {
      booking.status == 200 ? (flag = true) : (flag = false);
    }*/
    booking.status == 200 ? (flag = true) : (flag = false);
    flag ? (custBook = "circle") : (custBook = "circle-red");
    return custBook;
  } catch (error) {
    custBook = "circle-red";
    return custBook;
  }
}
module.exports = { getCustomerBooking };
