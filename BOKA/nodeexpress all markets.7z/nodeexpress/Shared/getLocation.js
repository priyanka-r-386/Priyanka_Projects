function getLocation(service_type) {
  service_type === "REMOTE" || service_type === "HOME"
    ? (service_type = "services")
    : (service_type = "locations");
  return service_type;
}

module.exports = { getLocation };
