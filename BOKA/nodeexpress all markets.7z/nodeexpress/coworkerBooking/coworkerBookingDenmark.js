const axios = require("axios");
const pinCode = "1620";
const language = "da-dk";

Date.prototype.GetFirstDayOfWeek = function () {
  return new Date(
    this.setDate(this.getDate() - this.getDay() + (this.getDay() == 0 ? -6 : 1))
  );
};
let monday = new Date().GetFirstDayOfWeek().toISOString().split("T")[0];
var date = new Date(monday);
var end_date = new Date(
  date.getFullYear(),
  date.getMonth(),
  date.getDate() + 28
)
  .GetFirstDayOfWeek()
  .toISOString()
  .split("T")[0];

let current_date = new Date().toISOString().slice(0, 10);

const fs = require("fs");

async function getBookingData1() {
  return async function (req, res, next) {
    fs.readFile("./Json Data/denmark/DK_01.json", (err, data) => {
      if (err) {
        console.log(err);
        next();
      }
      bookingData = JSON.parse(data);
      const coData = bookingData.map((res) => [res.status, res.type]);
      let flag = false;
      for (let i in coData) {
        if (coData[i][0] == "PUBLISHED" && coData[i][1] == "GENERAL_BOOKING") {
          flag = true;
        }
        break;
      }
      flag
        ? (coworkerbooking1_dk = "circle")
        : (coworkerbooking1_dk = "circle-red");
    });
    next();
  };
}
/*
function getBookingData1() {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://boka-coworker.ocp.ingka.ikea.com/appointment/service/2820/BUSINESS_PLANNING/range/2021-12-07/2021-12-07`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );
      console.log(booking);

      //app.locals.result = [...result, customer_booking2_dk];
      next();
    } catch (error) {
      console.log(error);
      next();
    }
  };
}*/
module.exports = { getBookingData1 };
