const axios = require("axios");
const pinCode = "1081";
const language = "no-no";

Date.prototype.GetFirstDayOfWeek = function () {
  return new Date(
    this.setDate(this.getDate() - this.getDay() + (this.getDay() == 0 ? -6 : 1))
  );
};
let start_date = new Date().GetFirstDayOfWeek().toISOString().split("T")[0];

function getBookingData1(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status == 200) {
        customer_booking_no = "circle";
      }

      next();
    } catch (error) {
      customer_booking_no = "circle-red";
      next();
    }
  };
}

function getBookingData2(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status === 200) customer_booking2_no = "circle";

      next();
    } catch (error) {
      customer_booking2_no = "circle-red";
      next();
    }
  };
}
function getBookingData3(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status === 200) customer_booking3_no = "circle";

      next();
    } catch (error) {
      customer_booking3_no = "circle-red";
      next();
    }
  };
}

function getBookingData4(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status === 200) customer_booking4_no = "circle";

      next();
    } catch (error) {
      customer_booking4_no = "circle-red";
      next();
    }
  };
}

function getBookingData5(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status === 200) customer_booking5_no = "circle";

      next();
    } catch (error) {
      customer_booking5_no = "circle-red";
      next();
    }
  };
}

function getBookingData6(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status === 200) customer_booking6_no = "circle";

      next();
    } catch (error) {
      customer_booking6_no = "circle-red";
      next();
    }
  };
}

function getBookingData7(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status === 200) customer_booking7_no = "circle";

      next();
    } catch (error) {
      customer_booking7_no = "circle-red";
      next();
    }
  };
}

function getBookingData8(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status === 200) customer_booking8_no = "circle";

      next();
    } catch (error) {
      customer_booking8_no = "circle-red";
      next();
    }
  };
}

function getBookingData9(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status === 200) customer_booking9_no = "circle";

      next();
    } catch (error) {
      customer_booking9_no = "circle-red";
      next();
    }
  };
}

function getBookingData10(services_type, actual_service) {
  return async function (req, res, next) {
    try {
      const booking = await axios.get(
        `https://order-timewindow.ocp.ingka.ikea.com/${services_type}/${pinCode}/${actual_service}?from=${start_date}`,
        {
          headers: {
            accept: "application/json",
            "accept-language": `${language}`, //the token is a variable which holds the token
          },
        }
      );

      if (booking.status === 200) customer_booking10_no = "circle";

      next();
    } catch (error) {
      customer_booking10_no = "circle-red";
      next();
    }
  };
}

module.exports = {
  getBookingData1,
  getBookingData2,
  getBookingData3,
  getBookingData4,
  getBookingData5,
  getBookingData6,
  getBookingData7,
  getBookingData8,
  getBookingData9,
  getBookingData10,
};
