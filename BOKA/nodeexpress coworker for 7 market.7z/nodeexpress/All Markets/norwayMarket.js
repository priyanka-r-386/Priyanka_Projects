const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = ["DESIGN", "BATHROOM", "PAX", "BUSINESS", "KITCHEN"];
const pinCode = "1081";
const language = "no-no";

async function getDesignNorway(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_no = designServices;
    next();
  } catch (error) {
    design_no = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBathroomNorway(req, res, next) {
  try {
    const bathroom = await data_services.getServiceData(
      services[1],
      pinCode,
      language
    );

    const bathroomServices = bathroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bathroom_no = bathroomServices;
    next();
  } catch (error) {
    bathroom_no = [error.response.status, error.response.statusText];
    next();
  }
}

async function getPaxNorway(req, res, next) {
  try {
    const pax = await data_services.getServiceData(
      services[2],
      pinCode,
      language
    );

    const paxServices = pax.data.map((sd) => sd.serviceProductId + "\n");
    pax_no = paxServices;
    next();
  } catch (error) {
    pax_no = [error.response.status, error.response.statusText];
    next();
  }
}

async function getKitchenNorway(req, res, next) {
  try {
    const kitchen = await data_services.getServiceData(
      services[4],
      pinCode,
      language
    );

    const kitchenService = kitchen.data.map((sd) => sd.serviceProductId + "\n");
    kitchen_no = kitchenService;
    next();
  } catch (error) {
    kitchen_no = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessNorway(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      services[3],
      pinCode,
      language
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_no = businessService;
    next();
  } catch (error) {
    business_no = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = {
  getBathroomNorway,
  getBusinessNorway,
  getDesignNorway,
  getKitchenNorway,
  getPaxNorway,
};
