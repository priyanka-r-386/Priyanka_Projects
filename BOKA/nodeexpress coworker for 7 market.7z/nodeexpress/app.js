const express = require("express");
const chalk = require("chalk");
const path = require("path");
const morgan = require("morgan");
const app = express();
const { response } = require("express");
const compression = require("compression");
const indiaMarket = require("./All Markets/indianMarket");
const denmarkMarket = require("./All Markets/denmarkMarket");
const polandMarket = require("./All Markets/polandMarket");
const portugalMarket = require("./All Markets/portugalMarket");
const netherlandMarket = require("./All Markets/netherlandMarket");
const ukMarket = require("./All Markets/UKMarket");
const norwayMarket = require("./All Markets/norwayMarket");
const serbiaMarket = require("./All Markets/serbiaMarket");
const finlandMarket = require("./All Markets/finlandMarket");
const customerBooking = require("./customerBooking/customerBookingPortugal");
const customerBookingPL = require("./customerBooking/customerBookingPoland");
const customerBookingDK = require("./customerBooking/customerBookingDenmark");
const customerBookingNL = require("./customerBooking/customerBookingNetherland");
const customerBookingIN = require("./customerBooking/customerBookingIndia");
const customerBookingNO = require("./customerBooking/customerBookingNorway");
const customerBookingUK = require("./customerBooking/customerBookingUK");
const coworkerBookingDK = require("./coworkerBooking/coworkerBookingDenmark");
const EventEmitter = require("events");
const { errorMonitor } = require("events");
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, "/public/")));

app.use(morgan("tiny"));

app.set("views", "./src/views");
app.set("view engine", "ejs");

app.use(compression());

app.use(express.static("public"));

function errorHandler(err, req, res, next) {
  console.error(err.stack);
  res.status(500).send("Something broke!");
}

class MyEmitter extends EventEmitter {}

const myEmitter = new MyEmitter();
// increase the limit
//myEmitter.setMaxListeners(Infinity);

app.get("/index", (req, res) => {
  res.render("header");
});

const service = ["services", "locations"];

const middlewares = [
  //coworkerBookingDK.getBookingData1,
  customerBooking.getBookingData2("services", "HOME_FURNISHING_BASIC_REMOTE"),
  customerBooking.getBookingData1("services", "HOME_FURNISHING_BASIC_CUSTOMER"),
  customerBooking.getBookingData3(
    "services",
    "HOME_FURNISHING_COMPLETE_REMOTE"
  ),
  customerBooking.getBookingData4("services", "PLANNING_SEASONAL_CUSTOMER"),
  customerBooking.getBookingData5("locations", "PLANNING_LIVING_ROOM"),
  customerBooking.getBookingData6("services", "PLANNING_LIVING_ROOM_REMOTE"),
  customerBooking.getBookingData7("locations", "PLANNING_WARDROBE"),
  customerBooking.getBookingData8("locations", "PLANNING_WARDROBE_CUSTOMER"),
  customerBooking.getBookingData9("services", "PLANNING_WARDROBE_REMOTE"),
  customerBooking.getBookingData10("locations", "BUSINESS_PLANNING"),
  customerBooking.getBookingData11(
    "locations",
    "PLANNING_KITCHEN_CUSTOMER_ADDITIONAL"
  ),
  customerBooking.getBookingData12("services", "PLANNING_KITCHEN_REMOTE"),
  customerBooking.getBookingData13(
    "locations",
    "PLANNING_KITCHEN_MEETING_POINT"
  ),

  customerBookingPL.getBookingData1(service[1], "HOME_FURNISHING_BASIC"),
  customerBookingPL.getBookingData2(
    service[1],
    "HOME_FURNISHING_BASIC_CUSTOMER"
  ),
  customerBookingPL.getBookingData3(service[1], "HOME_FURNISHING_BASIC_REMOTE"),
  customerBookingPL.getBookingData4("locations", "HOME_FURNISHING_COMPLETE"),
  customerBookingPL.getBookingData5(
    "locations",
    "HOME_FURNISHING_COMPLETE_CUSTOMER"
  ),
  customerBookingPL.getBookingData6(
    service[1],
    "HOME_FURNISHING_COMPLETE_REMOTE"
  ),
  customerBookingPL.getBookingData7(service[1], "PLANNING_LIVING_ROOM"),
  customerBookingPL.getBookingData8(service[1], "PLANNING_LIVING_ROOM_REMOTE"),
  customerBookingPL.getBookingData14(service[1], "PLANNING_HOME_SMART_REMOTE"),
  customerBookingPL.getBookingData9(service[1], "PLANNING_WARDROBE"),
  customerBookingPL.getBookingData10(service[1], "PLANNING_WARDROBE_REMOTE"),
  customerBookingPL.getBookingData11(service[1], "DECORATION_BUSINESS"),
  customerBookingPL.getBookingData12(service[1], "BUSINESS_PLANNING"),
  customerBookingPL.getBookingData13(service[1], "INTERIOR_DESIGN_BUSINESS"),
  customerBookingDK.getBookingData1(service[1], "HOME_FURNISHING_BASIC"),
  customerBookingDK.getBookingData2(service[1], "HOME_FURNISHING_BASIC_REMOTE"),
  customerBookingDK.getBookingData3(service[1], "BUSINESS_PLANNING"),
  customerBookingDK.getBookingData4(service[1], "PLANNING_BATHROOM_REMOTE"),
  customerBookingNL.getBookingData2(service[0], "PLANNING_LIVING_ROOM_REMOTE"),
  customerBookingNL.getBookingData1(service[1], "PLANNING_LIVING_ROOM"),
  customerBookingIN.getBookingData1(service[0], "DECORATION"),
  customerBookingIN.getBookingData2(service[1], "HOME_FURNISHING_BASIC"),
  customerBookingIN.getBookingData3(service[0], "HOME_FURNISHING_BASIC_REMOTE"),
  customerBookingIN.getBookingData4(service[0], "ID_BUSINESS_REMOTE"),
  customerBookingIN.getBookingData5(service[0], "PLANNING_LIVING_ROOM_REMOTE"),
  customerBookingIN.getBookingData6(service[0], "PLANNING_WARDROBE_REMOTE"),
  customerBookingNO.getBookingData1(service[1], "HOME_FURNISHING_BASIC"),
  customerBookingNO.getBookingData2(service[1], "HOME_FURNISHING_BASIC_REMOTE"),
  customerBookingNO.getBookingData3(service[1], "PLANNING_KITCHEN_REMOTE"),
  customerBookingNO.getBookingData4(
    service[1],
    "PLANNING_KITCHEN_MEETING_POINT"
  ),
  customerBookingNO.getBookingData5(service[1], "PLANNING_WARDROBE"),
  customerBookingNO.getBookingData6(service[1], "PLANNING_WARDROBE_REMOTE"),
  customerBookingNO.getBookingData7(service[1], "PLANNING_BATHROOM_REMOTE"),
  customerBookingNO.getBookingData8(service[1], "PLANNING_BATHROOM_STORE"),
  customerBookingNO.getBookingData9(service[1], "BUSINESS_PLANNING"),
  customerBookingNO.getBookingData10(service[0], "PLANNING_BUSINESS_REMOTE"),
  customerBookingUK.getBookingData1(
    service[0],
    "HOME_FURNISHING_COMPLETE_REMOTE"
  ),
  customerBookingUK.getBookingData2(service[1], "PLANNING_LIVING_ROOM"),
  customerBookingUK.getBookingData3(service[1], "PLANNING_LIVING_ROOM_REMOTE"),
  customerBookingUK.getBookingData4(service[1], "PLANNING_WARDROBE"),
  customerBookingUK.getBookingData5(service[1], "PLANNING_WARDROBE_REMOTE"),
  customerBookingUK.getBookingData6(service[0], "INTERIOR_DESIGN_BUSINESS"),
  customerBookingUK.getBookingData7(service[0], "VERIFY_PLANNING_AND_DRAWING"),
  customerBookingUK.getBookingData8(service[1], "PLANNING_KITCHEN_STORE"),
  customerBookingUK.getBookingData9(service[0], "PLANNING_KITCHEN_REMOTE"),
  customerBookingUK.getBookingData10(
    service[0],
    "INTERIOR_DESIGN_BUSINESS_CONSULTATION"
  ),

  //indiaMarket.getDesignIndia,
  //indiaMarket.getLRIndia,
  indiaMarket.getIndiaData,
  denmarkMarket.getDesignDenmark,
  denmarkMarket.getBusinessDenmark,
  denmarkMarket.getBathroomDenmark,
  polandMarket.getDesignPoland,
  polandMarket.getPaxPoland,
  polandMarket.getLRPoland,
  polandMarket.getBusinessPoland,
  polandMarket.getSmartHomePoland,
  portugalMarket.getBusinessPortugal,
  portugalMarket.getDesignPortugal,
  portugalMarket.getKitchenPortugal,
  portugalMarket.getLRPortugal,
  portugalMarket.getPaxPortugal,
  netherlandMarket.getLRNetherland,
  ukMarket.getBedroomUK,
  ukMarket.getBusinessConsultationUK,
  ukMarket.getDesignUK,
  ukMarket.getKitchenUK,
  ukMarket.getLRUK,
  ukMarket.getBusinessUK,
  norwayMarket.getBathroomNorway,
  norwayMarket.getBusinessNorway,
  norwayMarket.getDesignNorway,
  norwayMarket.getKitchenNorway,
  norwayMarket.getPaxNorway,
  serbiaMarket.getBedroomSerbia,
  serbiaMarket.getBusinessSerbia,
  serbiaMarket.getDesignSerbia,
  serbiaMarket.getKitchenSerbia,
  finlandMarket.getBathroomFinland,
  finlandMarket.getBedroomFinland,
  finlandMarket.getBusinessFinland,
  finlandMarket.getKitchenFinland,
  finlandMarket.getDesignFinland,
  finlandMarket.getLRFinland,
  finlandMarket.getTrailorFinland,
];
app.get(
  "/",
  [...middlewares],

  (req, res) => {
    res.render("index", {
      design_in: actual_service,
      lr_in: lr_service,
      pax_in: pax_service,
      design_dk: design_dk,
      business_dk: business_dk,
      bathroom_dk: bathroom_dk,
      design_pl: design_pl,
      pax_pl: pax_pl,
      lr_pl: lr_pl,
      business_pl: business_pl,
      sh_pl: sh_pl,
      design_pt: design_pt,
      lr_pt: lr_pt,
      pax_pt: pax_pt,
      kitchen_pt: kitchen_pt,
      business_pt: business_pt,
      lr_nl: lr_nl,
      design_uk: design_uk,
      lr_uk: lr_uk,
      business_uk: business_uk,
      bedroom_uk: bedroom_uk,
      kitchen_uk: kitchen_uk,
      business_consultation_uk: business_consultation_uk,
      design_no: design_no,
      pax_no: pax_no,
      kitchen_no: kitchen_no,
      bathroom_no: bathroom_no,
      business_no: business_no,
      bedroom_sr: bedroom_sr,
      design_sr: design_sr,
      kitchen_sr: kitchen_sr,
      business_sr: business_sr,
      bathroom_fl: bathroom_fl,
      business_fl: business_fl,
      bedroom_fl: bedroom_fl,
      design_fl: design_fl,
      kitchen_fl: kitchen_fl,
      business_fl: business_fl,
      trailor_fl: trailor_fl,
      design1_bk_pt: customer_booking,
      design2_bk_pt: customer_booking2,
      design3_bk_pt: customer_booking3,
      design4_bk_pt: customer_booking4,
      design5_bk_pt: customer_booking5,
      design6_bk_pt: customer_booking6,
      design7_bk_pt: customer_booking7,
      design8_bk_pt: customer_booking8,
      design9_bk_pt: customer_booking9,
      design10_bk_pt: customer_booking10,
      design11_bk_pt: customer_booking11,
      design12_bk_pt: customer_booking12,
      design13_bk_pt: customer_booking13,
      cust_book_pl1: customer_booking_pl,
      cust_book_pl6: customer_booking6_pl,
      cust_book_pl2: customer_booking2_pl,
      cust_book_pl3: customer_booking3_pl,
      cust_book_pl4: customer_booking4_pl,
      cust_book_pl5: customer_booking5_pl,
      cust_book_pl7: customer_booking7_pl,
      cust_book_pl8: customer_booking8_pl,
      cust_book_pl9: customer_booking9_pl,
      cust_book_pl10: customer_booking10_pl,
      cust_book_pl11: customer_booking11_pl,
      cust_book_pl12: customer_booking12_pl,
      cust_book_pl13: customer_booking13_pl,
      cust_book_pl14: customer_booking14_pl,
      cust_book_dk1: customer_booking_dk,
      cust_book_dk2: customer_booking2_dk,
      cust_book_dk3: customer_booking3_dk,
      cust_book_dk4: customer_booking4_dk,
      cust_book_nl1: customer_booking_nl,
      cust_book_nl2: customer_booking1_nl,
      cust_book_in1: customer_booking_in,
      cust_book_in2: customer_booking2_in,
      cust_book_in3: customer_booking3_in,
      cust_book_in4: customer_booking4_in,
      cust_book_in5: customer_booking5_in,
      cust_book_in6: customer_booking6_in,
      cust_book_no1: customer_booking_no,
      cust_book_no6: customer_booking6_no,
      cust_book_no2: customer_booking2_no,
      cust_book_no3: customer_booking3_no,
      cust_book_no4: customer_booking4_no,
      cust_book_no5: customer_booking5_no,
      cust_book_no7: customer_booking7_no,
      cust_book_no8: customer_booking8_no,
      cust_book_no9: customer_booking9_no,
      cust_book_no10: customer_booking10_no,
      cust_book_uk1: customer_booking_uk,
      cust_book_uk6: customer_booking6_uk,
      cust_book_uk2: customer_booking2_uk,
      cust_book_uk3: customer_booking3_uk,
      cust_book_uk4: customer_booking4_uk,
      cust_book_uk5: customer_booking5_uk,
      cust_book_uk7: customer_booking7_uk,
      cust_book_uk8: customer_booking8_uk,
      cust_book_uk9: customer_booking9_uk,
      cust_book_uk10: customer_booking10_uk,
      //coworker_dk1: coworkerbooking1_dk,
    });
  }
);
app.use;
//app.use(errorHandler);
app.listen(PORT, () => {
  console.log(`listening to port ${chalk.green(PORT)}`);
});
