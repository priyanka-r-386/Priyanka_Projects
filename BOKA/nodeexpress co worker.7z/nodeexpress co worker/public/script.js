const india = document.getElementById("india");
const norway = document.querySelector("#Norway");
const denmark = document.querySelector("#denmark");
const portugal = document.querySelector("#portugal");
const poland = document.getElementById("poland");
const netherland = document.querySelector("#netherland");
const UK = document.querySelector("#UK");
const serbia = document.querySelector("#serbia");
const finland = document.querySelector("#finland");

const services_group = document.querySelector(".service_group");

async function getBookingData1(url) {
  const response = await fetch(url);
  const bookingData = response.json();
  //const coData = bookingData.map((res) => [res.status, res.type]);
  return bookingData;
}

//Add Indian Market
india.addEventListener("input", function (e) {
  if (india.checked === true) {
    if (services_group.hasChildNodes(".services_india")) {
      services_group.appendChild(document.querySelector(".services_india"));
      document.querySelector(".services_india").style.display = "initial";
    }
  }
  //Remove market when unchecked
  if (india.checked === false) {
    console.log(services_group.childNodes);
    document.querySelector(".services_india").style.display = "none";
  }
});

//Add services to Norway Market
norway.addEventListener("input", function (e) {
  if (norway.checked === true) {
    services_group.appendChild(document.querySelector(".services_norway"));
    document.querySelector(".services_norway").style.display = "initial";
  }
  //Remove market when unchecked
  if (norway.checked === false) {
    document.querySelector(".services_norway").style.display = "none";
  }
});

// Adding Denmark Market
denmark.addEventListener("input", function (e) {
  if (denmark.checked === true) {
    if (services_group.hasChildNodes(".services_denmark")) {
      services_group.appendChild(document.querySelector(".services_denmark"));

      document.querySelector(".services_denmark").style.display = "initial";
    }
    getBookingData1("DK_HOME_FURNISHING_BASIC.json").then((res) => {
      const coData = res.map((result) => [result.status, result.type]);
      let flag = false;
      for (let i in coData) {
        if (coData[i][0] == "PUBLISHED" && coData[i][1] == "GENERAL_BOOKING") {
          flag = true;
        }
        break;
      }
      flag
        ? (coworkerbooking1_dk = "circle")
        : (coworkerbooking1_dk = "circle-red");
      const element = document.querySelector(".coworker-booking1-dk");
      element.classList.toggle(coworkerbooking1_dk);
    });
    getBookingData1("DK_HOME_FURNISHING_BASIC_REMOTE.json").then((res) => {
      const coData = res.map((result) => [result.status, result.type]);
      let flag = false;
      for (let i in coData) {
        if (coData[i][0] == "PUBLISHED" && coData[i][1] == "GENERAL_BOOKING") {
          flag = true;
        }
        break;
      }
      flag
        ? (coworkerbooking2_dk = "circle")
        : (coworkerbooking2_dk = "circle-red");
      const element = document.querySelector(".coworker-booking2-dk");
      element.classList.toggle(coworkerbooking2_dk);
    });
    getBookingData1("DK_BUSINESS_PLANNING.json").then((res) => {
      const coData = res.map((result) => [result.status, result.type]);
      let flag = false;
      for (let i in coData) {
        if (coData[i][0] == "PUBLISHED" && coData[i][1] == "GENERAL_BOOKING") {
          flag = true;
        }
        break;
      }
      flag
        ? (coworkerbooking3_dk = "circle")
        : (coworkerbooking3_dk = "circle-red");
      const element = document.querySelector(".coworker-booking3-dk");
      element.classList.toggle(coworkerbooking3_dk);
    });
    getBookingData1("DK_PLANNING_BATHROOM_REMOTE.json").then((res) => {
      const coData = res.map((result) => [result.status, result.type]);
      let flag = false;
      for (let i in coData) {
        if (coData[i][0] == "PUBLISHED" && coData[i][1] == "GENERAL_BOOKING") {
          flag = true;
        }
        break;
      }
      flag
        ? (coworkerbooking4_dk = "circle")
        : (coworkerbooking4_dk = "circle-red");
      const element = document.querySelector(".coworker-booking4-dk");
      element.classList.toggle(coworkerbooking4_dk);
    });
  }

  //Remove market when unchecked
  if (denmark.checked === false) {
    document.querySelector(".services_denmark").style.display = "none";
  }
});

//Add portugal Market
portugal.addEventListener("input", function (e) {
  if (portugal.checked === true) {
    services_group.appendChild(document.querySelector(".portugal_services "));
    document.querySelector(".portugal_services ").style.display = "initial";
  }
  //Remove market when unchecked
  if (portugal.checked === false) {
    document.querySelector(".portugal_services ").style.display = "none";
  }
});

//Netherland Market

netherland.addEventListener("input", function (e) {
  if (netherland.checked === true) {
    services_group.appendChild(document.querySelector(".services_netherland"));
    document.querySelector(".services_netherland").style.display = "initial";
  }
  //Remove market when unchecked
  if (netherland.checked === false) {
    document.querySelector(".services_netherland").style.display = "none";
  }
});
// Poland Market
poland.addEventListener("input", function (e) {
  if (poland.checked === true) {
    services_group.appendChild(document.querySelector(".services_poland"));
    document.querySelector(".services_poland").style.display = "initial";
  }
  //Remove market when unchecked
  if (poland.checked === false) {
    document.querySelector(".services_poland").style.display = "none";
  }
});

//UK Market
UK.addEventListener("input", function (e) {
  if (UK.checked === true) {
    services_group.appendChild(document.querySelector(".services_uk"));
    document.querySelector(".services_uk").style.display = "initial";
  }
  //Remove market when unchecked
  if (UK.checked === false) {
    document.querySelector(".services_uk").style.display = "none";
  }
});

// Serbia Market
serbia.addEventListener("input", function (e) {
  if (serbia.checked === true) {
    services_group.appendChild(document.querySelector(".services_serbia"));
    document.querySelector(".services_serbia").style.display = "initial";
  }
  //Remove market when unchecked
  if (serbia.checked === false) {
    document.querySelector(".services_serbia").style.display = "none";
  }
});

finland.addEventListener("input", function (e) {
  if (finland.checked === true) {
    services_group.appendChild(document.querySelector(".services_finland"));
    document.querySelector(".services_finland").style.display = "initial";
  }
  //Remove market when unchecked
  if (finland.checked === false) {
    document.querySelector(".services_finland").style.display = "none";
  }
});
