const express = require("express");
const data_services = require("../nodejs");
const app = express();
const services = ["LIVINGROOM"];
const pinCode = "1101 BL";
const language = "nl-nl";
const axios = require("axios");

/*async function getLRNetherland(req, res, next) {
  try {
    const lr = await data_services.getServiceData(
      services[0],
      pinCode,
      language
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_nl = lrServices;
    next();
  } catch (error) {
    
  }
}*/

async function getLRNetherland(req, res, next) {
  try {
    const lr = await axios.get(
      `https://order-timewindow.ocp.ingka.ikea.com/servicesbygroup/${pinCode}/${services[0]}`,
      {
        headers: {
          accept: "application/json",
          "accept-language": `${language}`, //the token is a variable which holds the token
        },
      }
    );

    const lrServices = lr.data.map((sd) => sd.serviceProductId + "\n");
    lr_nl = lrServices;

    next();
  } catch (error) {
    lr_nl = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = { getLRNetherland };
