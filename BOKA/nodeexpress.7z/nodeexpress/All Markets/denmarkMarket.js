const express = require("express");
const data_services = require("../nodejs");
const app = express();

async function getDesignDenmark(req, res, next) {
  try {
    const design = await data_services.getServiceData(
      "DESIGN",
      "1620",
      "da-dk"
    );

    const designServices = design.data.map((sd) => sd.serviceProductId + "\n");
    design_dk = designServices;
    next();
  } catch (error) {
    design_dk = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBusinessDenmark(req, res, next) {
  try {
    const business = await data_services.getServiceData(
      "BUSINESS",
      "1620",
      "da-dk"
    );

    const businessService = business.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    business_dk = businessService;
    next();
  } catch (error) {
    business_dk = [error.response.status, error.response.statusText];
    next();
  }
}

async function getBathroomDenmark(req, res, next) {
  try {
    const bathroom = await data_services.getServiceData(
      "BATHROOM",
      "1620",
      "da-dk"
    );

    const bathroomService = bathroom.data.map(
      (sd) => sd.serviceProductId + "\n"
    );
    bathroom_dk = bathroomService;
    next();
  } catch (error) {
    bathroom_dk = [error.response.status, error.response.statusText];
    next();
  }
}

module.exports = { getDesignDenmark, getBusinessDenmark, getBathroomDenmark };
